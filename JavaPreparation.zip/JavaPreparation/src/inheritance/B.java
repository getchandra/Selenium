package inheritance;

public class B {
	void msg(){
		System.out.println("Welcome");
		}

}
