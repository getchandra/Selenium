package inheritance;

public class A {
	void msg(){
		System.out.println("Hello");
	}
}
