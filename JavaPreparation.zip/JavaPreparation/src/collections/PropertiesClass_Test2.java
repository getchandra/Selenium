package collections;

import java.io.FileWriter;
import java.util.Properties;

public class PropertiesClass_Test2 {
	
	public static void main(String[] args)throws Exception{  
		  
		Properties p=new Properties();  
		p.setProperty("name","Chandrasekhara Varma.S");  
		p.setProperty("email","getchandra@javatpoint.com");  
		  
		p.store(new FileWriter("info.properties"),"Javatpoint Properties Example");  
		  
		}  

}
