package com.selenium.web.sanity;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.selenium.atnt.common.Common;
import com.selenium.web.base.WebTestCase;
import com.atnt.framework.common.Retry;
import com.atnt.framework.common.Screenshot;
import com.atnt.framework.dto.AddressObj;

@Listeners({ Screenshot.class })
public class ATnTBuildYourOwnBundleTest extends WebTestCase {
    private Common common = new Common(driver);
	private Logger logger = Logger.getLogger(ATnTBuildYourOwnBundleTest.class.getName()); 

    private WebDriver driver2 = driver;
    private AddressObj address = null;
 
    @BeforeClass
    public void initialize(ITestContext testContext) {
        testContext.setAttribute("driver", driver2);
    	address = (AddressObj) getSession().getAddresses().get("validaddress");

        getDriver().manage().deleteAllCookies();
        common.impicitWait(20);
        getDriver().manage().window().maximize();
        getDriver().get(getSession().getEnv().getUrl());
        getDriver().manage().timeouts().pageLoadTimeout(200, TimeUnit.SECONDS);
       
    }

    @AfterClass
    public void closeBrowser() {
        // / ds.closeFile();
        // WriteExcel.getInstance().closeFile();
        //driver2.manage().deleteAllCookies();
       // driver2.quit();
    }
    
    @Test(testName = "CheckBuildyYourOwnBundle", description = "verify title", timeOut = 4190000, enabled = true, groups = {
			"sanity", }, retryAnalyzer = Retry.class)
	public void CheckBuildyYourOwnBundle() {
		try {
			getPageFactory().getATnTHomePage().ClickonPrimaryNav();
			
			//Thread.sleep(40000);
			
		    //getPageFactory().getATnTAvailabilityPage().ClickOnCheckAvailabiltyButton(s1,s2,s3);
			getPageFactory().getATnTAvailabilityPage().ClickOnCheckAvailabiltyButton(address.getStreetAddress(),address.getUnitNumber(),address.getZipCode());
			System.out.println("bundle page");
			//Thread.sleep(90000);
			getPageFactory().getATntTBuildYourOwnBundlePage().VerifyPageTile();
			
			//getPageFactory().ATnTBuildYourOwnBundlePage().VerifyPageTile();
		} catch (Exception e) {
			getDriver().get(getSession().getEnv().getUrl());
			Assert.assertTrue(false, "test case one failed verifying home page links");
		}
	}
}