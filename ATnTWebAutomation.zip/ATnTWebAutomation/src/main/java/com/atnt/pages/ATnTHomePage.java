package com.atnt.pages;

import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.selenium.atnt.common.Common;
import com.atnt.pages.Elements;
import com.atnt.framework.common.TestSession;

/**
 * This class contains total functionality related to At&t home page - www.att.com
 * 
 * @author prashant kumar
 *
 *  
 */

public class ATnTHomePage {

    private WebDriver driver;// = selenium.getDriver();
    private Common common;// = new Common();
	private TestSession session;
	//# private Logger logger = Logger.getLogger(SmokeTest.class.getName());

	@FindBy(xpath = Elements.primaryNavHomeLogoLink)
	private WebElement PrimaryNavHomeLogoLink;
	
	@FindBy(xpath = Elements.primaryNavShopLink)
	private WebElement PrimaryNavShopLink;
	
	@FindBy(xpath = Elements.primaryNavShopBundlesLink)
	private WebElement primaryNavShopBundlesLink;
	
	
	
	@FindBy(xpath = Elements.primaryNavShopWirelessSmartPhone)
	private WebElement PrimaryNavShopWirelessSmartPhone;
		
	
	@FindBy(xpath = Elements.primaryNavMyATnTLink)
	private WebElement PrimaryNavMyATnTLink;
	
	@FindBy(xpath = Elements.primaryNavSupportLink)
	private WebElement PrimaryNavSupportLink;
	
	@FindBy(xpath = Elements.primaryNavSearchBox)
	private WebElement PrimaryNavSearchBox;
	@FindBy(xpath = Elements.buildYourOwnBundle)
	private WebElement buildYourOwnBundle;
	

	public ATnTHomePage(WebDriver driver2) {
	    driver = driver2;
	    common  = new Common(driver2);
		PageFactory.initElements(driver2, this);
		session = new TestSession();
	}


	/**
	 *   Method to click all Primary Nav Links
	 */
	public void ClickonPrimaryNav() {
		//System.out.println("inside");
		common.MouseHoverFunction(PrimaryNavShopLink);
		//System.out.println("inside2");
		common.MouseHoverFunction(primaryNavShopBundlesLink);
		//System.out.println("inside3");
		
		buildYourOwnBundle.click();
		//System.out.println("inside4");
		//aa1.moveToElement(toplevel);
		//aa1.build().perform();
		//aa1.click();
		//Thread.sleep(6000);
		
	}

 }
