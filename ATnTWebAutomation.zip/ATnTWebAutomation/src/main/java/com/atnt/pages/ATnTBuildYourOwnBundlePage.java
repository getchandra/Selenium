package com.atnt.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.atnt.framework.common.TestSession;
import com.selenium.atnt.common.Common;

public class ATnTBuildYourOwnBundlePage {
	 private WebDriver driver;// = selenium.getDriver();
	    private Common common;// = new Common();
		private TestSession session;
		
		
		@FindBy(xpath = Elements.pageTitle)
		private WebElement PageTitle;
		
		@FindBy(xpath = Elements.selectAplanButton)
		private WebElement SelectAPlan;
		
		public ATnTBuildYourOwnBundlePage(WebDriver driver2) {
		   //System.out.println("ATnTBuildYourOwnBundlePage");
			driver = driver2;
		    common = new Common(driver2);
			PageFactory.initElements(driver2, this);
			session = new TestSession();
		}
		
		
		/**
		 *   Method to click all Primary Nav Links
		 * @throws Exception 
		 */
		public void VerifyPageTile() throws Exception {
			
			System.out.println("inside VerifyPageTile fucn ");
			common.waitForElement(SelectAPlan, 10000,driver);
			
			System.out.println(driver.getCurrentUrl());
			Thread.sleep(4000);
			SelectAPlan.click();
			System.out.println(PageTitle.getText());
			System.out.println("done");
			
		}


}
