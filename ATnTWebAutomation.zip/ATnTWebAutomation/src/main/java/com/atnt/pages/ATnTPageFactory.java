package com.atnt.pages;

import org.openqa.selenium.WebDriver;


public class ATnTPageFactory {
	private ATnTHomePage ATnTHomePage;// = new ATnTHomePage();
	private ATnT_EDS_AvailabilityPage ATnT_EDS_AvailabilityPage;
	private ATnTBuildYourOwnBundlePage ATnTBuildYourOwnBundlePage;

	
	public ATnTPageFactory(WebDriver driver){
		System.out.println("ATnTPageFactory constrctor");
		ATnTHomePage = new ATnTHomePage(driver);
		ATnT_EDS_AvailabilityPage=new ATnT_EDS_AvailabilityPage(driver);	
		ATnTBuildYourOwnBundlePage=new ATnTBuildYourOwnBundlePage(driver);
	}


	public ATnTHomePage getATnTHomePage() {
		return ATnTHomePage;
	}
	public ATnT_EDS_AvailabilityPage getATnTAvailabilityPage() {
		return ATnT_EDS_AvailabilityPage;
	}
	public ATnTBuildYourOwnBundlePage getATntTBuildYourOwnBundlePage() {
		return ATnTBuildYourOwnBundlePage;
	}
	
	
}