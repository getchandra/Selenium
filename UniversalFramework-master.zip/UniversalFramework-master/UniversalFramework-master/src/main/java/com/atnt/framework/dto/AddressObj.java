package com.atnt.framework.dto;

public class AddressObj {
	
	    private String streetaddress;
	    private String unitnumber;
	    private String zipcode;
	    
	    public String getStreetAddress() {
	        return streetaddress;
	    }
	    public void setStreetAddress(String streetAddress) {
	        this.streetaddress = streetAddress;
	    }
	    public String getUnitNumber() {
	        return unitnumber;
	    }
	    public void setUnitNumber(String unitnumber) {
	        this.unitnumber = unitnumber;
	    }
	    
	    public String getZipCode() {
	        return zipcode;
	    }
	    public void setZipCode(String zipcode) {
	        this.zipcode = zipcode;
	    }

}
