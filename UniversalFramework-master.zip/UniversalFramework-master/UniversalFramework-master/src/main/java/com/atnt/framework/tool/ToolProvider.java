package com.atnt.framework.tool;

import org.openqa.selenium.WebDriver;

import com.atnt.framework.exception.InValidOSException;
import com.atnt.framework.exception.InValidToolException;

public interface ToolProvider {
	
	/**
	 * Method to be called by all projects to their driver based on Tool and OS
	 * 
	 * @param cName
	 * @param os
	 * @return
	 * @throws InValidOSException
	 * @throws InValidToolException
	 */
	public WebDriver getToolsDriver( Tools.SupportedTools cName, String os) throws InValidOSException, InValidToolException;
}