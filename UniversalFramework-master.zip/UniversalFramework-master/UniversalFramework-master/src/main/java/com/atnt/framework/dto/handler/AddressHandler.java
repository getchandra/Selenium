package com.atnt.framework.dto.handler;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.atnt.framework.dto.AddressObj;
import com.atnt.framework.dto.UserObj;

public class AddressHandler {
	 private static AddressHandler _instance;
	    private static InputStream in;
	    
	    private static final String FILEPATH_QA = "src/test/resources/address.properties";
	   
	    private static Properties addresses = new Properties();
	    private static Map<String,AddressObj> addressMap = null;
	    private static String mylocale = "en_US";
	    private static String myenv = "QA";

	    public static AddressHandler getInstance(String locale, String env) {
	        mylocale = locale;
	        myenv = env;
	        if (_instance == null) {
	            _instance = new AddressHandler();
	        }
	        return _instance;
	    }
	    
	    private AddressHandler() {
	        loadAddressProperties();
	    }

	    private void loadAddressProperties() {
	        try {
	            if (mylocale.equals("en_US") && myenv.equals("QA")) {
	                in = new FileInputStream(System.getProperty("user.dir") + "/"
	                        + FILEPATH_QA);
	            }
	            
	            addresses.load(in);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public static Map<String, AddressObj> getAddressMap() {
	        if(addressMap == null){
	        	addressMap = new HashMap<String, AddressObj>();
	        	AddressObj address = null;
	        for (String key : addresses.stringPropertyNames()) {
	            String value = addresses.getProperty(key);

	            String[] completeaddress = value.split(",");
	            address = new AddressObj();
	            address.setStreetAddress(completeaddress[0]);
	            address.setUnitNumber(completeaddress[1]);
	            address.setZipCode(completeaddress[2]);
	            addressMap.put(key, address);
	        }
	        
	        }
	        return addressMap;
	    }

}
