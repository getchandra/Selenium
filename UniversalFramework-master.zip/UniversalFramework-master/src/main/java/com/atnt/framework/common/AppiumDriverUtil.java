package com.atnt.framework.common;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.atnt.framework.dto.Capability;
import com.atnt.framework.dto.Envirnoment;
import com.atnt.framework.dto.handler.CapabilityHandler;
import com.atnt.framework.dto.handler.EnvirnomentHandler;

public class AppiumDriverUtil {
    private static Capability capability = CapabilityHandler.getInstance()
            .getCapability();
    private static Envirnoment env = EnvirnomentHandler.getInstance()
            .getEnvirnoment();

    private  AndroidDriver androiddriver = null;
    private  IOSDriver iosdriver = null;

    public  AndroidDriver getAndroidDriver() {
        if (androiddriver == null && env.isLocal()) {
            File appDir = new File(capability.getFilePath());
            File app = new File(appDir, capability.getApplicationName());
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("device", capability.getDevice());
            capabilities.setCapability("platform", capability.getPlatform());
            capabilities.setCapability("version", capability.getVersion());
            capabilities.setCapability("newCommandTimeout", "300");
            capabilities
                    .setCapability("deviceType", capability.getDeviceType());
            capabilities
                    .setCapability("deviceName", capability.getDeviceName());
            capabilities.setCapability("platformName",
                    capability.getPlatformName());
            capabilities.setCapability("app", app.getAbsolutePath());
            capabilities.setCapability("app-package",
                    capability.getAppPackage());
            capabilities.setCapability("app-activity",
                    capability.getAppActvity());

            try {
                androiddriver = new AndroidDriver(new URL(
                        capability.getAppiumServerPath()), capabilities);
                Thread.sleep(5000);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return androiddriver;
        } else if (androiddriver == null && !env.isLocal()) {
            androiddriver = (AndroidDriver) getTestDroidDriver(capability.getPlatform());
            return androiddriver;
        }
        return androiddriver;
    }

    // TODO implement for IOS driver
    public  IOSDriver getIOSDriver() {
        // set up appium
        if (iosdriver == null && env.isLocal()) {
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("device", capability.getDevice());
            capabilities
                    .setCapability("deviceName", capability.getDeviceName());
            // capabilities.setCapability("udid",
            // "2bd76408db2e3ad25e2142038579baa8b2c3aff3");
            capabilities.setCapability("platformName",
                    capability.getPlatformName());
            capabilities.setCapability("platformVersion",
                    capability.getVersion());
            capabilities.setCapability("bundleid", capability.getBundleid());
            File appDir = new File(capability.getFilePath());
            File app = new File(appDir, capability.getApplicationName());
            capabilities.setCapability("app", app.getAbsolutePath());
            try {
                iosdriver = new IOSDriver(new URL(
                        capability.getAppiumServerPath()), capabilities);
            } catch (MalformedURLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            return iosdriver;
        } else if (iosdriver == null && !env.isLocal()) {
            iosdriver = (IOSDriver) getTestDroidDriver(capability.getPlatform());
            return iosdriver;
        }
        else {
            return iosdriver;
        }
    }

    private static AppiumDriver getTestDroidDriver(final String platform) {
        AppiumDriver driver = null;
        String testdroid_username = capability.getTestdroid_username();
        String testdroid_password = capability.getTestdroid_password();

        if (StringUtils.isEmpty(testdroid_password)
                || StringUtils.isEmpty(testdroid_username)) {
            throw new IllegalArgumentException(
                    "Missing TESTDROID_USERNAME or/and TESTDROID_PASSWORD environment variables");
        }

        String fileUUID = null;
        try {
            fileUUID = TestDroidUtil.uploadFile(capability.getFilePath()
                    + File.separator + capability.getApplicationName(),
                    capability.getTestdroidServerPath(), testdroid_username,
                    testdroid_password);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities
                .setCapability("platformName", capability.getPlatformName());
        capabilities.setCapability("testdroid_target",
                capability.getTestdroid_target());
        capabilities.setCapability("deviceName", capability.getDeviceName());

        capabilities.setCapability("testdroid_username",
                capability.getTestdroid_username());
        capabilities.setCapability("testdroid_password",
                capability.getTestdroid_password());

        if ("android".equalsIgnoreCase(platform)) {
            capabilities.setCapability("testdroid_project", "SiriusXMAndroid");
            capabilities.setCapability("testdroid_testrun",
                    "Regression Android Run" + System.currentTimeMillis());
        } else if ("IOS".equalsIgnoreCase(platform)) {
            capabilities.setCapability("testdroid_project", "SiriusXMIOS");
            capabilities.setCapability("testdroid_testrun",
                    "Regression IOS Run" + System.currentTimeMillis());
        }

        // See available devices at:
        // https://cloud.testdroid.com/#public/devices
        capabilities.setCapability("testdroid_device",
                capability.getTestdroid_device());
        capabilities.setCapability("testdroid_app", fileUUID);

        System.out.println("Capabilities:" + capabilities.toString());

        System.out
                .println("Creating Appium session, this may take couple minutes..");
        try {

            if ("android".equalsIgnoreCase(platform)) {
                driver = new AndroidDriver(new URL(
                        capability.getTestdroidServerPath() + "/wd/hub"),
                        capabilities);
            } else if ("IOS".equalsIgnoreCase(platform)) {
                driver = new IOSDriver(new URL(
                        capability.getTestdroidServerPath() + "/wd/hub"),
                        capabilities);
            }

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return driver;
    }
}