package week5.statickeyword;

public class RunStaticFunction {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		StaticBlocks staticObj = new StaticBlocks();
		
		// Bad Approach
		staticObj.showStaticMethod();
		// Good Approach
		StaticBlocks.showStaticMethod();
	}

}

