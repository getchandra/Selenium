package week5.multipleinheritance;

public class A {
	
	public void doHomework(){
		
	}

}
