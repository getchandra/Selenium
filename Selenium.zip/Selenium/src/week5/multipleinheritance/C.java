package week5.multipleinheritance;

public class C extends B {

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		C c = new C();
//		c.doHomework();
		
	}

}
