package week5.multipleinheritance;

public class B {

	public void doHomework() {

	}

}