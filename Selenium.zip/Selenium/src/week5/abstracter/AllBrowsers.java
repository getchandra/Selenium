package week5.abstracter;

public abstract class AllBrowsers {
	//
	// This is good method across all browsers
	public void getLinksCount() {
		
	}
	
	// This method will not work correctly for all browser
	public abstract void getBrowserSize();

}

