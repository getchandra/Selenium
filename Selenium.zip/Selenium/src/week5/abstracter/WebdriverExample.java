package week5.abstracter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

@SuppressWarnings("unused")
public class WebdriverExample {
	public static void main(String[] args){
		WebDriver driver = new FirefoxDriver();
//		WebDriver driver2 = new FirefoxDriver();
		driver.findElement(By.id(" "));
//		driver.findElementById(" ");
	}
}
