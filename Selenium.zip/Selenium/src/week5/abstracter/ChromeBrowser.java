package week5.abstracter;

public abstract class ChromeBrowser extends AllBrowsers{
		
}
