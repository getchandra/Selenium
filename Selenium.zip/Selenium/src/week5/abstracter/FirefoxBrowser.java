package week5.abstracter;

public class FirefoxBrowser extends AllBrowsers{

	@Override
	public void getBrowserSize() {
		// TODO Auto-generated method stub
		
	}

}
