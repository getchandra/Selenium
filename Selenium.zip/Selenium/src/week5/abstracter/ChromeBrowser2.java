package week5.abstracter;

public  class ChromeBrowser2 extends ChromeBrowser{

	@Override
	public void getBrowserSize() {
		// TODO Auto-generated method stub
		
	}
}
