package week5.implement;

public class FirefoxBrowser implements AllBrowsers{

	@Override
	public void getBrowserSize(){
		
	}

	@Override  //declared two time uneccarily
	public void getLinksCount() {
		// TODO Auto-generated method stub	
	}	
}

