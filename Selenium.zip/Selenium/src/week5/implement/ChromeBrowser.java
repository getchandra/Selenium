package week5.implement;

public class ChromeBrowser implements AllBrowsers{

	@Override
	public void getLinksCount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getBrowserSize() {
		// TODO Auto-generated method stub
		
	}	
}
