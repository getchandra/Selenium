package week5.implement;

public interface AllBrowsers {
	
	// This is good method across all browsers
	public void getLinksCount() ;
	
	// This method will not work correctly for all browser
	public void getBrowserSize();

}
