package week5.finalkeyword;

/**
 * @author Karim Final Class, which can't be extend / inherited
 *
 */
public  final class FinalClass {

	public void nonFinalMetod() {
		System.out.println("I am in FinalClass : finalMetod()  ");
	}
	
	
	public final void finalMetod() {
		System.out.println("I am in FinalClass : finalMetod()  ");
	}

}

