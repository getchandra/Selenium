package week5.reflections;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

@SuppressWarnings("unused")
public class TestLeafDetails {

	@SuppressWarnings("rawtypes")
	public static void main(String[] args) throws SecurityException, NoSuchMethodException, IllegalArgumentException,
InstantiationException, IllegalAccessException, InvocationTargetException {

	Class<TestLeafCompany> testLeaf = TestLeafCompany.class;
// Know the center name
// System.out.println("What is the name of centre with package : " +
// testLeaf.getName());
// System.out.println("What is the name of the centre " +
// testLeaf.getSimpleName());
// Know the method names i.e what are the details published to public to
// know
// about the company
		
	Method[] methodName = testLeaf.getMethods();

	for (Method knowDetails : methodName) {
	System.out.println(knowDetails.getDeclaringClass());
	System.out.println(knowDetails.getName());
		}

// To know constructor details

	Constructor[] constructors = testLeaf.getConstructors();

	for (Constructor constructor : constructors) {
	System.out.println("Constructor : " + constructor.getName());
	}

	Class superclass = testLeaf.getSuperclass();
	System.out.println("Super class is " + superclass);
		
	}

}
