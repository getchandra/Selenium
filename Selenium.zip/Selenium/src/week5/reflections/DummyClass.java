package week5.reflections;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.firefox.FirefoxDriver;

public class DummyClass {

	public static void main(String[] args) {
// Open Firefox Browser
// Syntax to call another class
// ClassName onjName = new ClassName();
	
	FirefoxDriver driver = new FirefoxDriver();

		
// Maximize the browser
	driver.manage().window().maximize();

// implicit wait
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

// Syntax to call method
// objName.methodName();
// Load the URL
	driver.get("http://demo1.opentaps.org/");

	}

}
