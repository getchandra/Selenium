package week5.reflections;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.internal.compiler.ast.SuperReference;

@SuppressWarnings("unused")
public class TestLeafCompany extends DummyClass{

	public TestLeafCompany(String nameOfUserLooking) {

		System.out.println("Hello - " + nameOfUserLooking + " Welocme to TeastLeaf can I help you !! - ");

	}

	// Fees details can be shared to public
	// so we are creating as public method
	public int getSeleniumFeeDetails() {
		int fees = 10000;
		return fees;
	}

	// Students are not required to know staff names
	// so we are creating as private method
	private List<String> getStaffNames() {

		List<String> mentorList = new ArrayList<String>();
		mentorList.add("Karim");
		mentorList.add("Venu");
		mentorList.add("Bharath");
		mentorList.add("Raju");
		mentorList.add("Sakthi");
		mentorList.add("Vijay");
		for (String staffList : mentorList) {
			System.out.println("StaffList but order not required :" + staffList);
		}

		List<String> mentorListWithSeniority = new ArrayList<String>();
		mentorListWithSeniority.add("Karim");
		mentorListWithSeniority.add("Venu");
		mentorListWithSeniority.add("Bharath");
		mentorListWithSeniority.add("Raju");
		mentorListWithSeniority.add("Sakthi");
		mentorListWithSeniority.add("Vijay");
		for (String staffList : mentorList) {
			System.out.println("StaffList  order is required :" + mentorListWithSeniority);
		}

		return mentorList;

	}

// To enquire we need the address to public and accessable to all
	public String getContactUS() {
	String testLeafOfficeAdd = "No:##, XXX Street, XXX Nagar, Chennai - #####";
	System.out.println("Address wihtout Contact No - " + testLeafOfficeAdd);

// In future if number get changes, we can use same address and memory
// rather creating new one
	StringBuffer newAddress = new StringBuffer(testLeafOfficeAdd);
	newAddress.append("Phone No : 9*****74");
	System.out.println("Address with Contact No - " + testLeafOfficeAdd);
	return null;

	}

}

