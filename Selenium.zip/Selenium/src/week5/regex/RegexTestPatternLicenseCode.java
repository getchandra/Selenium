package week5.regex;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

public class RegexTestPatternLicenseCode {

	private static String license1 = "23fg-h13h-h2h3-80az";

	// private static String license2 = "h23b-12as-mn12-d67h";

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		Pattern pattern = Pattern.compile("[1-9a-zA-Z]{2}");

		// in case you would like to ignore case sensitivity,

		// you could use this statement:

		// Pattern pattern = Pattern.compile("\\s+",Pattern.CASE_INSENSITIVE);

		Matcher matcher = pattern.matcher(license1);

		// check all occurance

		while (matcher.find()) {

			System.out.print("Start index: " + matcher.start());
			System.out.print("  End index: " + matcher.end());
			System.out.print("  Length of word  " + (matcher.end() - matcher.start()));

			System.out.println("    The word is " + matcher.group());

		}

		// now create a new pattern and matcher to replace whitespace with tabs
		//
		Pattern replace = Pattern.compile("\\s+");

		// Matcher matcher2 = replace.matcher(Alphabetical);

		// System.out.println(matcher2.replaceAll("%"));

	}

}
