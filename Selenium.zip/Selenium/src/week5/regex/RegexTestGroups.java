package week5.regex;

//import java.util.regex.Matcher;

//import java.util.regex.Pattern;

public class RegexTestGroups {

    
public static void main(String[] args) {
        
String Alphabetical = "Testleaf training institute September batch training";
        
String Alphanumeric = "Testleaf 123 institute item1234dispatched batch training";
        
String specialcharacters = "a@ b# c% d&";

        
String pattern1 = "[tT]";
        
String pattern2 = "[0-9]";
        
String pattern3 = "\\W";
        
System.out.println("Replace the word t by \n"+Alphabetical.replaceAll(pattern1,"I"));
 
       
System.out.println("Replace the numbers t by abc \n" + Alphanumeric.replaceAll(pattern2, "abc"));
        
System.out.println("Replace the special characters by 1 \n" + specialcharacters.replaceAll(pattern3, "1"));

//        System.out.println(EXAMPLE_TEST.replaceAll(pattern,"%"));

//        System.out.println(EXAMPLE_TEST.replaceAll(pattern,"%"));

    }

}