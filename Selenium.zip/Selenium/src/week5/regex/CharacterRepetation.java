package week5.regex;
import java.util.HashMap;

import java.util.Map;

public class CharacterRepetation {
    
public static void main(String[] args) {

//        String companyname_String = " tcs ,  cts ,  wipro ,  infosys , wipro ,  infosys, cts ,  wipro ,  infosys, wipro ,  infosys , tcs , cts , tcs ,  cts ,  wipro ,  infosys wipro ,  infosys cts ,  wipro , infosys wipro ,  infosys , tcs ,  cts";

String[] comanyname = {"tcs", "cts", "wipro", "infosys"
                , "wipro", "infosys"
                , "cts", "wipro", "infosys"
                , "wipro", "infosys"
                ,"tcs", "cts"
                ,"tcs", "cts", "wipro", "infosys"
                , "wipro", "infosys"
                , "cts", "wipro", "infosys"
                , "wipro", "infosys"
                ,"tcs", "cts"};

//        comanyname = companyname_String.split(",");

        Map<String, Integer> wordCounter = new HashMap<String, Integer>();
        for (String word : comanyname) {
            
Integer count = wordCounter.get(word);
            
if (count == null) {
                
wordCounter.put(word, 1);
            
} 
else {
                
wordCounter.put(word, count + 1);
            
}
        
}
        
System.out.println(wordCounter.toString());
    
}

}
