package week5.regex;
import java.util.regex.Matcher;

import java.util.regex.Pattern;


/**
 * Created by Bharathan on 25/10/15.
 * Created on 25/10/15 1:35 AM
 */


public class RegexTestPatternMatcher {
    
private static String Alphabetical = "Testleaf training institute September batch test training";
    
//private static String Alphanumeric = "Testleaf 123123 institute item1234dispatched batch training";

    
public static void main(String[] args) {
        
Pattern pattern = Pattern.compile("\\S+");
        
// in case you would like to ignore case sensitivity,
        
// you could use this statement:
        
// Pattern pattern = Pattern.compile("\\s+",Pattern.CASE_INSENSITIVE);
 

Matcher matcher = pattern.matcher(Alphabetical);
        
// check all occurance
        
while (matcher.find()) {
            
System.out.print("Start index: " + matcher.start());
            System.out.print("  End index: " + matcher.end());
            System.out.print("  Length of word  " + (matcher.end()-matcher.start()));
            

System.out.println("    The word is " + matcher.group());
        
}
    
// now create a new pattern and matcher to replace whitespace with tabs


//Pattern replace = Pattern.compile("\\s+");

//Matcher matcher2 = replace.matcher(Alphabetical);

//System.out.println(matcher2.replaceAll("%"));
    
}

}
