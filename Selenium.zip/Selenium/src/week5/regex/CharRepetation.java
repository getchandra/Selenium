package week5.regex;

//import java.util.HashMap;

import java.util.Map;

import java.util.Map.Entry;

import java.util.TreeMap;



public class CharRepetation {
    
public static void main(String[] args) {
        
String wiproString = "wipro Info Limited";
   		
char[] chararry = wiproString.toLowerCase().toCharArray();

        Map<Character, Integer> wordCounter = new TreeMap<Character, Integer>();
        
for (Character word : chararry) {
            
Integer count = wordCounter.get(word);
            
if (count == null)
                
wordCounter.put(word, 1);
            
else 
                
wordCounter.put(word, count + 1);            
        
}
        
        
// print map
        
System.out.println(wordCounter.toString());
        
        
int maxVal = 0; 
char maxKey = 0;
        
for (Entry<Character,Integer> word : wordCounter.entrySet()) {
        	if(word.getValue() > maxVal){
        		
maxVal = word.getValue();
        		
maxKey = word.getKey();
        	
}
		
}
               
System.out.println(maxKey);
        
System.out.println(maxVal);
   
}
    
}

