package week5.stringMethods;

public class HashCodeExample {
	public static void main(String args[]) {

		String str1 = new String("Welcome!! Bharath");

		System.out.println("Hash Code for String str: " + str1.hashCode());

		str1 = "Welcome!!";

		System.out.println("Hash Code for String str: " + str1.hashCode());

		StringBuilder str3 = new StringBuilder("Welcome!!");
		
		System.out.println("Hash Code for String str: " + str3.hashCode());

		// str3 = new StringBuilder("Welcome Karim!!");

		str3.append("Welcome Karim!!");

		System.out.println("Hash Code for String str: " + str3.hashCode());

		/*
		 * 
		 * hashCode() method
		 * 
		 * This method returns the hash code for the String. The computation is
		 * done like this:
		 * 
		 * s[0] 31^(n-1) + s[1]*31^(n-2) + ... + s[n-1]
		 * 
		 */

	}

}
