package week5.stringMethods;

public class StringConcatenate {
	public static void main(String args[]) {
        

		//One way of doing concatenation
		        
		String str1 = "Welcome";
		        
		str1 = str1.concat(" to ");
		        
		str1 = str1.concat(" String handling ");
		        
		System.out.println(str1);

		        

		//Other way of doing concatenation in one line
		        
		String str2 = "This";
		        
		str2 = str2.concat(" is").concat(" just a").concat(" String");
		        System.out.println(str2);

		        
		String s="";
		        
		s.concat("abc");
		        
		s.concat("abc");

//will throw NullPointerException.
		    
		}

	/*
	 * 1. Java.lang.NullPointerException :
	 * 
	 * concat() method if called on null String reference variable, will throw
	 * NullPointerException while this is not the case with + operator.
	 * 
	 * For example,
	 * 
	 * String s=null; s.concat(“abc�?);
	 * 
	 * 
	 * 
	 * will throw NullPointerException.
	 * 
	 * While
	 * 
	 * String s=null;
	 * 
	 * 
	 * System.out.println(s+�?abc�?);
	 * 
	 * 
	 * 
	 * Will print nullabc. While concatenating strings with + operator, a null
	 * reference variable changes to “null�? (i..e a String containing null
	 * as its contents.). That’s why s becomes “null�? and output is
	 * nullabc.
	 * 
	 * 
	 * 
	 * 2. Number of arguments:
	 * 
	 * concat() takes only one argument while + can take any number of
	 * arguments.
	 * 
	 * Example,
	 * 
	 * “I�?+“ am�?+�? a�?+�? good�?+�? boy�?
	 * 
	 * 
	 * 
	 * 3. Type of Argument:
	 * 
	 * Signature of concat() method is: public String concat(String str)
	 * 
	 * concat() only takes String type as argument. If any other type argument
	 * is passed to concat() it will give compile time error. Example,
	 * 
	 * s.concat(5);
	 * 
	 * // error as 5 is a non string value
	 * 
	 * s.concat(“5�?); // no error as here 5 is string (enclosed in “�?)
	 * 
	 * While + can take any type of arguments. While doing concatenation
	 * non-string type argument is converted to String by using its toString()
	 * method
	 * 
	 * For example,
	 * 
	 * String s=�?abc�?;
	 * 
	 * 
	 * int i=5;
	 * 
	 * 
	 * System.out.println(s+i);
	 * 
	 * // no error, will print abc5.
	 * 
	 * Here int value 5 is a primitive value. It will be first converted to a
	 * string value as:
	 * 
	 * 
	 * 
	 * int------>Integer.toString(5)-------> a String representation of int
	 * value 5.
	 * 
	 * 
	 * Note that as explained in article String concatenation operator +, at
	 * least one argument of + must be of string type otherwise + will behave
	 * like mathematical addition operator instead of string concatenation
	 * operator.
	 * 
	 */
	/*
	 * http://java-journal.blogspot.in/2010/12/difference-between-concat-and-
	 * string.html
	 */

}


