package week5.stringMethods;

public class StringCharArrayExample {
	public static void main(String args[]) {

		String str = new String("Welcome to BeginnersBook.com");

		char[] array = str.toCharArray();

		System.out.print("Content of Array:");

		for (char c : array) {

			System.out.print(c);

		}

	}

}
