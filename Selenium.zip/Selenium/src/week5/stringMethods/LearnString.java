package week5.stringMethods;

public class LearnString {
@SuppressWarnings("unused")
public static void main(String[] args) {
		
		/**
		 * String class to create and manipulate strings.
		 * 
		 * Methods
		 * 1) length
		 * 2) charAt(index)
		 * 3) concat //Concatenate two strings only
		 * 4) toString() // Convert an existing data type
		 * 5) subString(beginIndex, endIndex) //Extracts a particular portion of String
		 * 6) trim // Removes the white space on begining and End
		 * 7) toLowerCase, toUpperCase // to convert case
		 * 8) split(regex, limit) //
		 * 9) indexOf(chr, startIndex) , lastIndexOf(chr, startIndex)
		 * 10)startsWith(s), endsWith(s), contains(s)
		 * 11)replace(oldChar, newChar), replaceAll(regex, replacement)
		 * 12)Immutable String, StringBuffer
		 */
		// Simplest way to create String
	
		String text = " Hexaware "; 
		
		//As literals
		// Another way to create String
		
		char[] another = {'t','e','s','t','l','e','a','f'};
		String newText = new String(another);
		
		// Creating object
		// The String class has thirteen constructors that allow you to provide the 
		// initial value of the string using different sources
		// Length
		
		System.out.println("The length of the string is :"+text.length());
		
		// get the last character
		
		System.out.println("The last character is :"+text.charAt((text.length()-1)));
		
		// concat
		
		System.out.println("The concatenation can be :"+text.concat("Chennai").concat(" will offer better job"));
		
		// Another way is using + to concatenate
		// convert to String -- applies to Integer, Double, Float, Boolean
		
		Integer value = 10;
		
		System.out.println(value.toString()); 
		int valInt = Integer.parseInt("10");
		double valDouble = Double.parseDouble("10");
		System.out.println(valDouble);
		
		// SubString
		
		System.out.println("The first 5 character of Hexaware is : "+text.substring(0,5));
		
		// trim - removes white space
		
		System.out.println("Without white spaces on both end :"+text.trim());
		
		// to lowercase
		
		System.out.println("The text in lowercase is : "+text.toLowerCase());
		
		// split the string my delimiter
		
		String[] data = text.split("",4);
		System.out.println("The array size is : "+data.length);
		System.out.println("The second character is : "+data[3]);
		
		// find the index of 'a'
		
		System.out.println("The first occurance of index 'a' in ' Hexaware ' is : "+text.indexOf("e",3));
		
		// find the last index of 'a'
		
		System.out.println("The last occurance of index 'a' in ' Hexaware ' is : "+text.lastIndexOf("a"));
		
		
		// Confirm if the text has character 'w'
		
		System.out.println("Does the string has character 'w' : "+text.contains("w"));
		
		// Replace all (white spaces with nothing)
		
		System.out.println("The white spaces removed text is :"+text.replaceAll(" ", ""));
		
		// least 
		// Check the memory address
		
		System.out.println("The present memory address of String is : "+Integer.toHexString(newText.hashCode()));
		
		// Change the text value
		
		newText = "TestLeaf";
		System.out.println("The changed memory address of String is : "+Integer.toHexString(newText.hashCode()));
		
/*//		StringBuffer str = new StringBuffer("TestLeaf"); 
//		System.out.println("The present memory address of StringBuffer is : "+Integer.toHexString(str.hashCode()));
		
		str.insert(0, "New ");
		System.out.println(str);
		System.out.println("The changed memory address of StringBuffer is : "+Integer.toHexString(str.hashCode()));

		*/
	}

}



