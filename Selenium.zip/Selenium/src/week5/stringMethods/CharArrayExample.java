package week5.stringMethods;

public class CharArrayExample {
	public static void main(String args[]) {

		String str = new String("Welcome to BeginnersBook.com");

		char[] array = str.toCharArray();

		System.out.println("Content of Array:");

		for (char c : array) {

			System.out.println("" + c );

		}

	}
}
