package week5.stringMethods;

public class StringBuilderTest {
	public static void main(String[] args) {

		/* Creating StringBuilder */

		StringBuilder buffer = new StringBuilder("hello");

		/* Use append to concatenate */

		buffer.append("java");
		
		buffer.append(5);

		System.out.println(buffer);

	}

}
