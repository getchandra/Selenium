package week5.stringMethods;

public class StringBufferTest {

	public static void main(String[] args) {

		/* Creating StringBuffer */

		StringBuffer buffer = new StringBuffer("hello");

		/* Use append to concatenate */

		buffer.append("java");

		buffer.append(5);

		System.out.println(buffer);

	}

}
