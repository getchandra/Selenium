package testng;


import org.testng.Assert;

import org.testng.annotations.Parameters;

import org.testng.annotations.Test;

import org.testng.AssertJUnit.*;




/**
 * Created by Bharathan on 08/08/15.
 */


@SuppressWarnings("unused")
public class Parameter1 {

    

@Parameters({ "first-name" })
    

@Test
    
public void testSingleString(String lastName) {
        System.out.println("Invoked testString " + lastName);

// 	int[] array1 = {1,2,3,4,5};
 
//       int[] array2 = {5,4,3,2,1};

//        assert "Cedric".equals(lastName+1);

//        Assert.assertEquals(array2, array1);
 
//       Assert.assertSame("BHarath","Ram");

//        Assert.
    
}

}
