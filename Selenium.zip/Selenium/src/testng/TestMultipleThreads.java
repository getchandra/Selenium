package testng;

/**
 * Created by Bharathan on 22/11/15.
 * Created on 22/11/15 12:55 AM
 */


import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.Assert;

import org.testng.annotations.Test;



public class TestMultipleThreads {

	

@Test(threadPoolSize = 10)
	
public void loadTestThisWebsite() {
		
System.out.printf("%n[START] Thread Id : %s is started!",Thread.currentThread().getId());

		
WebDriver driver = new FirefoxDriver();
		
driver.get("http://www.google.com");
		
System.out.println("Page Title is " + driver.getTitle());
		Assert.assertEquals("Google", driver.getTitle());
		System.out.printf("%n[END] Thread Id : %s", Thread.currentThread().getId());
		
driver.quit();

	
}

}
