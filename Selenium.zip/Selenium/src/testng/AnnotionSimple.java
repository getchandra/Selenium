package testng;


import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.annotations.*;


import java.util.concurrent.TimeUnit;



/**
 * Created by Bharathan on 21/11/15.
 * Created on 21/11/15 11:24 PM
 */


public class AnnotionSimple {
    
WebDriver driver;

    

@BeforeMethod
    
public void vehicleStart() {
        
driver.get("http://www.jetstar.com/au/en/home");
    
}

    

@AfterMethod
    
public void vehicleStop() {
        
driver.get("about:blank");
    
}

    

@BeforeClass
    
public void openParking() {
        
driver = new FirefoxDriver();
        
driver.manage().window().maximize();
        
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    
}

    

@AfterClass
    
public void closeParking() {
        
driver.quit();
    
}

    

@Test(groups = "Navigation")
    
public void navigationAvailablity(){
        
int count = driver.findElements(By.xpath("//ul[@class='nav clearfix']/li")).size();
        
System.out.println("Count of Navigational link " + count);
    
}   

@Test(groups = "Advertisement")
    
public void advertaisementAvailablity(){
        
int count = driver.findElements(By.xpath("//div[@class='navi']/a")).size();
        
System.out.println("Count of advertaisement link " + count);
    
}

}
