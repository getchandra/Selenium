package testng;


import org.testng.annotations.*;



@Test(groups = {"Mobile", "Electronics"})

public class FlipMobile {

    

@Test(groups = {"setup"})
    
public void factoryMobile() {
        
System.out.println("Mobile Factory");
    
}

    

@Test(groups = {"Samsung", "Smoke", "Regression", "Prod"})
    
public void samsungGalaxy() {
        
System.out.println("Samsung Galaxy");
    
}

    

@Test(groups = {"Samsung", "Regression"})
    
public void samsungGalaxyAce() {
        
System.out.println("Samsung Ace");
    
}

    

@Test(groups = {"Zenphone", "Regression", "Prod"})
    
public void zenFoneSelfie() {
        
System.out.println("ZenFone Selfie");
    
}

    

@Test(groups = {"Zenphone", "Regression"})
    
public void zenFoneDeluxe() {
        
System.out.println("ZenFone Deluxe");
    
}

    

@Test(groups = {"lenovo", "Smoke", "Regression", "Prod"})
    
public void lenovoVibe() {
        
System.out.println("Lenovo Selfie");
    
}

    

@Test(groups = {"lenovo", "Regression", "Prod"})
    
public void lenovoProfessional() {
        
System.out.println("Lenovo Professinal");
    
}

    

@Test(groups = {"Microsoft", "Regression", "Prod"})
    
public void lumia1200() {
        
System.out.println("Samsung Galaxy");
    
}

    

@Test(groups = {"Microsoft", "Regression"})
    
public void lumia635() {
        
System.out.println("Samsung Galaxy");
    
}

    

@BeforeClass
    
public void BrowserConfiguration() {
        
System.out.println("");
        
System.out.println("Set Up Data related to Mobile specific Class");
    System.out.println("");
    
}

    

@AfterClass
    
public void closeParking() {
        
System.out.println("");
        
System.out.println("Clear Data related to Mobile specific Class");
     System.out.println("");
    
}

    

@BeforeMethod()
    
public void browserSetup() {
        
System.out.println("Open Flipkart-Mobile Page");
        System.out.println("");
    
}

    

@AfterMethod
    
public void browserCleanUp() {
        
System.out.println("");
        
System.out.println("Close Flipkart Page");
        
System.out.println("");
    
}

}