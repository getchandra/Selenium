package testng;
 

import java.util.concurrent.TimeUnit;


import org.junit.Assert;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.annotations.AfterClass;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Parameters;

import org.testng.annotations.Test;

 

@SuppressWarnings("unused")
public class ParallelSuiteTest
{
	
WebDriver driver1;
	
WebDriver driver2;
	

@Test
	
public void spiCinimas() throws InterruptedException {
		
driver1 = new FirefoxDriver();
		
driver1.manage().window().maximize();
		
driver1.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver1.get("http://www.spicinemas.in/");
		
Thread.sleep(10000);
		
String title = driver1.getTitle();
		
Assert.assertEquals("SPI Cinemas - Movie show times, buy tickets online", title);
		
driver1.quit();
	
}
	
	

@Test
	
public void justTickets() throws InterruptedException {
		
driver2 = new FirefoxDriver();
		
driver2.manage().window().maximize();
		
driver2.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
driver2.get("https://www.justickets.in/chennai");
		Thread.sleep(10000);

		
String title = driver2.getTitle();
		
Assert.assertEquals("Book your tickets in Chennai on Justickets", title);
		
driver2.quit();
	
}

}