package testng;


import org.testng.annotations.Test;


/**
 * Created by Bharathan on 08/08/15.
 */


public class InvocationCount {
	
int i = 0;

	

@Test(invocationCount = 6)
	
public void invocationcount() {
		
i++;
		
System.out.println("Execution iteration " + i);
	
}

}

