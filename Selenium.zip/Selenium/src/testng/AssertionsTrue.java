package testng;



/**
 * Created by Bharathan on 05/09/15.
 * Created on 05/09/15 11:07 PM
 */



import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import org.testng.annotations.Test;



public class AssertionsTrue {
	
WebDriver driver;

	

@Test
	
public void assertTrue() {
		
driver = new FirefoxDriver();
		
driver.navigate().to("http://google.com");
		Assert.assertTrue(driver.findElement(By.name("btnK")).isDisplayed());
	driver.close();
	
}

	

@Test
	
public void assertFalse() {
		
driver = new FirefoxDriver();
		
driver.navigate().to("https://the-internet.herokuapp.com/jqueryui/menu");
		
System.out.println(driver.findElement(By.linkText("Disabled")).isEnabled());
		
Assert.assertTrue(driver.findElement(By.linkText("Disabled")).isEnabled());
		
driver.close();

}


}
