package testng;


import java.util.concurrent.TimeUnit;

import org.junit.Assert;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.annotations.DataProvider;

import org.testng.annotations.Test;



public class ParameterizedLoginTest {
	 
WebDriver driver;

	

@Test(dataProvider = "parameterCredentials")
	
public void parameterIntArrayTest(String UserName, String Password) {
	
driver = new FirefoxDriver();
		
driver.manage().window().maximize();
		
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
driver.get("https://sandbox.braintreegateway.com/login");
		driver.findElement(By.id("login")).sendKeys(UserName);
		driver.findElement(By.id("password")).sendKeys(Password);
		driver.findElement(By.id("password")).submit();
		
WebElement header = driver.findElement(By.className("header_group"));
	Assert.assertEquals("Welcome to the Sandbox", header.getText());
	}
	

	

// This function will provide the parameter data
	
// Selenium framework - read the data from xls file and put it in Object
	
// array
	
// rows - number of time test has to be repeated
	
// cols - number of parameters in test data
	
	

@DataProvider(name = "Data-Credentials")
	
public Object[][] 
parameterCredentials() {

		
Object[][] 
data = new Object[2][2];

		
data[0][0] = "bharathjpss";
		
data[0][1] = "ARUNmozhi1";

		
data[1][0] = "bharathjpss2";
		
data[1][1] = "ARUNmozhi2";

		
return data;
	
}


}
