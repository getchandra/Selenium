package testng;

import org.testng.annotations.Test;

public class TestThreadPoolSize {
	
	@Test(invocationCount=5, threadPoolSize=10)
	public void run() throws InterruptedException{
		System.out.println("run started");
		Thread.sleep(5000);
		System.out.println("run ended");

	}

}
