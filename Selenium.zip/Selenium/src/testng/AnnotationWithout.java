package testng;



public class AnnotationWithout {
	

//Need to created Main Method
	

public static void main (String[] args){
		

AnnotationWithout obj = new AnnotationWithout();
	
obj.authenticateSeucrityOpen();
		
		obj.openParking();

obj.vehicleStart();
		
obj.splendor();
		
obj.vehicleStop();
		
	
obj.vehicleStart();
		
obj.honda();
		
obj.vehicleStop();
		
		
obj.vehicleStart();
		
obj.enfield();
		
obj.vehicleStop();
		
		
obj.vehicleStart();
		
obj.maruthi();
		
obj.vehicleStop();
		
		
obj.vehicleStart();
		
obj.hyundai();
		
obj.vehicleStop();
		
		
obj.vehicleStart();
		
obj.ford();
		
obj.vehicleStop();
		
		
obj.vehicleStart();
		
obj.vehicleStop();
		
		
obj.closeParking();
		
obj.authenticateSeucrityClose();
		
obj.openParking();
		
obj.closeParking();
		
	
}
	

public void splendor() {
		
System.out.println("Splendor bike Come out");
	
}

	

public void honda() {
		
System.out.println("Honda bike Come out");
	
}

	

public void enfield() {
		
System.out.println("Enfield bike Come out");
	
}

	

public void ford() {
		
System.out.println("Ford bike Come out");
	
}

	

public void maruthi() {
		
System.out.println("Maruthi bike Come out");
	
}

	

public void hyundai() {
		
System.out.println("Hyundai bike Come out");
	
}

	

public void vehicleStart() {
		
System.out.println("Start Vehicle: Ignition ON");
	
}

	

public void vehicleStop() {
		
System.out.println("Stop Vehicle: Ignition OFF");
		System.out.println("");
	
}


	

public void openParking() {
		
System.out.println("");
		
System.out.println("Parking Opened");
		
System.out.println("");
	
}

	

public void closeParking() {
		
System.out.println("");
		
System.out.println("Parking closed");
		
System.out.println("");
	
}

	

public void authenticateSeucrityOpen() {
		System.out.println("");
		
System.out.println("Verify Secirit to open the House door.");
		System.out.println("");
	
}

	

public void authenticateSeucrityClose() {
		System.out.println("");
		
System.out.println("Verify Secirity to close the House door.");
		System.out.println("");
	
}

}
