package testng;


import org.testng.Assert;

import org.testng.annotations.Test;


public class AnnotationPriority {

	

@Test(priority = 1)
	
public void splendor() {
		
System.out.println("Splendor bike Comes out");
		
Assert.fail("Im failing");
	}

	

@Test(priority = 2)
	
public void ford() {
		
System.out.println("Ford car Come out");
	
}


}
