package testng;


import org.testng.annotations.*;


public class AnnotationGroupAlwaysRun {

	

@Test(groups = "bike")
	
public void splendor() {
		
System.out.println("Splendor bike Comes out");
	
}
 
	

@Test(groups = "car")
	
public void ford() {
		
System.out.println("Ford car Come out");
	
}

	

@Test(groups = "bicycle")
	
public void bsa() {
		
System.out.println("bsa bicycle Come out");
	
}

	

@BeforeMethod(alwaysRun = true)

public void vehicleStart() {
	
System.out.println("Start Vehicle: Ignition ON");
	
}

	

@AfterMethod(alwaysRun = true)
	
public void vehicleStop() {
		
System.out.println("Stop Vehicle: Ignition OFF");
	System.out.println("");
	
}

	

@BeforeClass(alwaysRun = true)
	
public void openParking() {
		
System.out.println("");
		
System.out.println("Parking Opened");
		
System.out.println("");
	
}

	

@AfterClass(alwaysRun = true)
	
public void closeParking() {
		
System.out.println("");
		
System.out.println("Parking closed");
		
System.out.println("");
	
}

	

@BeforeTest(alwaysRun = true)
	
public void authenticateSeucrityOpen() {
		System.out.println("");
		
System.out.println("Verify Secirity to open the House door.");
		
System.out.println("");
	
}

	

@AfterTest(alwaysRun = true)
	
public void authenticateSeucrityClose() {
		System.out.println("");
		
System.out.println("Verify Secirity to close the House door.");
		
System.out.println("");
	
}

	

@BeforeSuite(alwaysRun = true)
	
public void beforeSuite() {
		
System.out.println("");
		
System.out.println("Start from Home");
		
System.out.println("");
	
}

	

@AfterSuite(alwaysRun = true)
	
public void afterSuite() {
		
System.out.println("");
		
System.out.println("Return to Home");
		
System.out.println("");
	
}

}

