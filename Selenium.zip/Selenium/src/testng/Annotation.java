package testng;


import org.testng.annotations.Test;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.AfterClass;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeSuite;

import org.testng.annotations.AfterSuite;



public class Annotation{

	

@Test
	
public void splendor() {
		
System.out.println("Splendor bike Comes out");
	
}


	
@Test
	
public void honda() {
		
System.out.println("Honda bike Come out");
	
}

    

@Test
	
public void enfield() {
		
System.out.println("Enfield bike Come out");
	
}

	
	
@Test
	
public void ford() {
		
System.out.println("Ford car Come out");
	
}

	

@Test
	
public void maruthi() {
		
System.out.println("Maruthi car Come out");
	
}

    

@Test
	
public void hyundai() {
		
System.out.println("Hyundai car Come out");
	
}

    

//Commented for reference

	

@BeforeMethod
	
public void vehicleStart() {
		
System.out.println("Start Vehicle: Ignition ON");
	
}

	

@AfterMethod
	
public void vehicleStop() {
		
System.out.println("Stop Vehicle: Ignition OFF");
		System.out.println("");
	
}

	

@BeforeClass
	
public void openParking() {
		
System.out.println("");
		
System.out.println("Parking Opened");
		
System.out.println("");
	
}

	

@AfterClass
	
public void closeParking() {
		
System.out.println("");
		
System.out.println("Parking closed");
		
System.out.println("");
	
}


	
@BeforeTest
	
public void authenticateSeucrityOpen() {
		System.out.println("");
		
System.out.println("Verify Secirity to open the House door.");
		System.out.println("");
	
}

	

@AfterTest
	
public void authenticateSeucrityClose() {
		System.out.println("");
		
System.out.println("Verify Secirity to close the House door.");
		System.out.println("");
	
}

	

@BeforeSuite
	
public void beforeSuite() {
		
System.out.println("");
		
System.out.println("Start from Home");
		
System.out.println("");
	
}

	

@AfterSuite
	
public void afterSuite() {
		
System.out.println("");
		
System.out.println("Return to Home");
		
System.out.println("");
	
}


}
