package testng;



import org.testng.annotations.Test;



public class Annotationdescription {

	

@Test(description = "Splendor Bike Test Case")
	
public void splendor() {
		
System.out.println("Splendor bike Comes out");
	
}


	

@Test(description = "Ford Car Test Case")
	
public void ford() {
		
System.out.println("Ford car Come out");
	
}


}

