package testng;


import org.testng.Assert;

import org.testng.annotations.*;



public class AnnotationDepends {

	
@Test(dependsOnMethods = "ford")
	
public void splendor() {
		
System.out.println("Splendor bike Comes out");
	
}


	

@Test 
	public void ford() {
		
System.out.println("Ford dint Come out");
         
Assert.fail("Ford dint Come out");
  	
}

}
