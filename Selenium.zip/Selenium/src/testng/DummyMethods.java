package testng;


import org.openqa.selenium.remote.RemoteWebDriver;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.AfterClass;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeSuite;

import org.testng.annotations.AfterSuite;


import java.util.NoSuchElementException;



@SuppressWarnings("unused")
public class DummyMethods {

 
   
@Test(invocationCount = 3)
    
public void f() {

        
System.out.println("SignUp");
    
}

    

@Test
    
public void login() {

        
System.out.println("Login");
        
throw new NoSuchElementException();
    
}

    

@Test(dependsOnMethods = "login")

    
public void Crlead() throws Exception {

        
System.out.println("CreateLead");

    
}

    

@Test(dependsOnMethods = "login")

    
public void Craccount() throws Exception {

        
System.out.println("CreateAccount");

    
}

    

@Test(dependsOnMethods = "login")

    
public void Logout() throws Exception {

        
System.out.println("Logout");
    
}

    

@Test
    
public void deletlead() {

        
System.out.println("DeleteLead");

    
}

@Test(alwaysRun = true)

    
public void logout() {

        
System.out.println("Logout");
    
}
}