package testng;


import org.testng.annotations.Test;

import org.testng.Assert;


public class RepeatTest {

  
int count = 0;

  

@Test
  
public void normal() {
    
System.out.println("repeat..." + (++count));
  
}

  

@Test(invocationCount = 30, successPercentage=98)
  public void successRate() {
    
System.out.println("repeat..." + (++count));
    
if (count > 15) {
      
Assert.fail("fail with count > 15");
    
}   
  
}

}