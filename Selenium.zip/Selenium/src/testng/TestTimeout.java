package testng;



import org.testng.annotations.Test;


/**
 * Created by Bharathan on 22/11/15.
 * Created on 22/11/15 1:00 AM
 */


public class TestTimeout {

    

@Test(timeOut = 5000) 
// time in mulliseconds
    
public void testThisShouldPass() throws InterruptedException {
        Thread.sleep(4000);
    
}
@Test(timeOut = 1000)

public void testThisShouldFail() {
        
while (true);
    
}


}


    
