package testng;


import org.testng.annotations.*;



@Test(groups = {"Mobile", "Electronics"})


public class FlipBase {

    

@BeforeSuite
    
public void baseSetUp() {
        
System.out.println("");
        
System.out.println("Set up Folder");
        
System.out.println("Delete/Archieve Perivious Data");
        System.out.println("");
    
}

    

@BeforeTest
    
public void environmentSetUp() {
        
System.out.println("");
        
System.out.println("Set Environment Parameter");
        System.out.println("Browser Configuration");
        System.out.println("");
    
}

    

@AfterTest
    
public void environmentClean() {
        
System.out.println("");
        
System.out.println("Clear Environment Parameters");
        System.out.println("");
    
}

    

@AfterSuite
    
public void tearDown() {
        
System.out.println("");
        
System.out.println("Zip Folder");
        
System.out.println("Send the reports");
        
System.out.println("");
    
}


}

