package testng;


import org.testng.annotations.Test;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.AfterClass;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.AfterTest;



public class AnnotationParking {
  

@Test
  
public void honda() {
	  
System.out.println("Take Honda out");
  
}
  
  

@Test
  
public void hundai() {
	  
System.out.println("Take Hundai out");
  
}

  

@BeforeMethod
  
public void beforeMethod(){
	  
System.out.println("Igniation On");
  
}
  
  

@AfterMethod
  
public void afterMethod() {
	  
System.out.println("Igniation Off");
  
}

  

@BeforeClass
  
public void beforeClass() {
	  
System.out.println("Open the parking gate");
  
}

  

@AfterClass
  
public void afterClass() {
	  
System.out.println("Close the parking gate");
  
}

  

@BeforeTest
  
public void beforeTest() {
	  
System.out.println("Open the security gate");
  
}

  

@AfterTest
  
public void afterTest() {
	  
System.out.println("Close the security gate");
  
}


}

