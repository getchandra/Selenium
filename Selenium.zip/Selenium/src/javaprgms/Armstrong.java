package javaprgms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.poi.ss.formula.ptg.PowerPtg;

@SuppressWarnings("unused")
public class Armstrong {
	
	int input;
	
	public void input() throws NumberFormatException, IOException
	{
		System.out.println("Enter the number : ");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		input= Integer.parseInt(br.readLine());
		System.out.println("Entered Number is : " +input);		
		
	}
	
	public void armstrong()
	{
		int a=input,b=0,sum=0;
		while(a>0) {
			b=a%10;	
			a=a/10;
			sum=sum + (b*b*b);
		}
		if(sum==input)
			System.out.println("Armstrong");
		else
			System.out.println("not an armstrong");
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		Armstrong a = new Armstrong();
		a.input();
		a.armstrong();

	}
}
