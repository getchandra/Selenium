package javaprgms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Swap {
	int a,b;
	
	public void input() throws NumberFormatException, IOException
	{
		System.out.println("Enter a : ");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		a= Integer.parseInt(br.readLine());
		System.out.println("Enter b : ");
		br=new BufferedReader(new InputStreamReader(System.in));
		b= Integer.parseInt(br.readLine());
		System.out.println("Entered Numbers are : " + a + " "+b);		
	}
	
	public void swap()
	{
		int c;
		c=a;
		a=b;
		b=c;
		System.out.println("After swapping : " + a + "  " + b);
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		Swap s = new Swap();
		s.input();
		s.swap();
	}

}

