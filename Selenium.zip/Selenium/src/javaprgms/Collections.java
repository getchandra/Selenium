package javaprgms;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

@SuppressWarnings("unused")
public class Collections {
	String s =  "AmazonXwillXofferXyouXifXyouXsolveXitXinX90Xseconds";// "tcs,tcs,tcs,tcs,cts,cts,cts,infy,infy,cts,infy,infy,tcs,tcs,tcs,cts,infy,tcs,tcs,infy,infy,infy,infy,cts,tcs,infy,cts,cts,cts,cts";
	Map<String, Integer> map = new TreeMap<String, Integer>();
	Set<Integer> count= new TreeSet<Integer>();
	Integer[] count2;
	List<Integer> count1= new LinkedList<Integer>();
	
	@SuppressWarnings("rawtypes")
	public void repeat() {
		Integer i;
		boolean alreadyPresent;
		i = 1;
		for (String s1 : s.split("")) {
			alreadyPresent = false;
				for(Entry e : map.entrySet())
				{
					if(e.getKey().equals(s1))
					{
						alreadyPresent = true;
						i=Integer.parseInt(e.getValue().toString())+1;
						map.put(s1,i);
						break;
					}
				}
				if(!alreadyPresent)
				{
					map.put(s1,1);
				}
		}

		System.out.println("----------Map Values----------");
		for (Entry<String, Integer> e : map.entrySet()) {
			System.out.println(e.getKey() + " " + e.getValue());
			count.add(e.getValue());
		}
		
		System.out.println("-------------Set Values-------------");
		for(Integer i1:count)
		{
			System.out.println(i1);
			count1.add(i1);
		}
		
		System.out.println("company with least is : ");
		for(Integer i1:count)
		{
			for(Entry e : map.entrySet())
			{
				if(e.getValue().equals(i1))
				{
					System.out.println(e.getKey());
				}
			}break;
		}	
		
		System.out.println("company with least is : " + count1.get(0));
		System.out.println("company with max is : " + count1.get(count1.size()-1));
		
		System.out.println("-------------Company with max is -----------------");
			for(Entry e : map.entrySet())
			{
				if(e.getValue().equals(count1.get(count1.size()-1)))
				{
					System.out.println(e.getKey());
				}
			}	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Collections repeatingCharacters = new Collections();
		repeatingCharacters.repeat();
	}

}
