package javaprgms;

public class ReverseString {
	Character[] s1 = new Character[50];
	int j=0;

	public void method1(String s) {
		for (int i = s.length()-1; i >=0; i--) {
			System.out.print(s.charAt(i));
		}
	}
	
	public void method2(String s){

		for (int i = s.length()-1; i >=0; i--) {
			s1[j++] = s.charAt(i);
		}
		for(int i=0;i<j;i++)
		System.out.print(s1[i]);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ReverseString reverseString = new ReverseString();
		reverseString.method1("Gowtham Raj");
		System.out.println();
		reverseString.method2("Gowtham Raj");
	}

}

