package javaprgms;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

@SuppressWarnings("unused")
public class WrapperClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WrapperMethods wrapper = new WrapperMethods();
		wrapper.openApp("firefox", "url");
		wrapper.snapshot();

	}

}

