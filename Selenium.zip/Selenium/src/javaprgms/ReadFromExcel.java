package javaprgms;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@SuppressWarnings("unused")
public class ReadFromExcel {
	
	/**
	 * @throws IOException
	 */
	FileInputStream fis;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	XSSFRow row;
	XSSFCell cell;
	ArrayList<String>[][] list;
	
	public void writeExcel() throws IOException
	{
		fis=new FileInputStream(new File("\\Selenium\\Test.xlsx"));
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheetAt(0);
		row = sheet.createRow(0);
		cell = row.createCell(0);
		for(int i=0; i<=5; i++) {
			row = sheet.createRow(i);
			
			for(int j=0;j<=5;j++)
			{
				cell = row.createCell(j);
				cell.setCellValue("Row" + i + "col" + j);
				
			}
		}
		FileOutputStream fos=new FileOutputStream(new File("\\Selenium\\Test.xlsx"));
		workbook.write(fos);
		
		fis.close();
		fos.close();
	}
	
	@SuppressWarnings("unchecked")
	public void readExcel() throws IOException
	{
		list = new ArrayList[6][6];
		fis=new FileInputStream(new File("\\Selenium\\Test.xlsx"));
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheetAt(0);
		for(int i=0; i<=5; i++) {
			row = sheet.getRow(i);
			for(int j=0;j<=5;j++)
			{
				list[i][j]=new ArrayList<String>();
				cell = row.getCell(j);
				list[i][j].add("aa" + cell.getStringCellValue());				
			}
		}
		for(int i=0; i<=5; i++) {
			for(int j=0;j<=5;j++)
			{
				System.out.print("Row " + i + "col " + j + "value : " + list[i][j]);
			}
			System.out.println();
		}
		fis.close();
}
	
	public static void main(String[] args) throws IOException {
		
		ReadFromExcel readFromExcel = new ReadFromExcel();
		readFromExcel.writeExcel();
		readFromExcel.readExcel();
	}

}
