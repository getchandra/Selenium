package javaprgms;

public class LeastRepeat {
	String s = "Amazon will offer you if you solve it in 90 seconds";
	char c;
	String[][] a = new String[100][2];
	String[][] a1 = new String[100][2];
	String b;
	int occurance, highestNum, j, k, l, l1;
	String secondLeast;
	Integer times;

	public void repeat() {

		k = 0;

		for (int i = 0; i < s.length(); i++) {
			times = 0;
			c = s.charAt(i);
			occurance = s.indexOf(c, 0);

			while (occurance != -1) {
				times = times + 1;
				occurance = s.indexOf(c, occurance + 1);
			}

			a[k][0] = String.valueOf(c);
			a[k][1] = times.toString();
			k++;
		}
		System.out.println("--------Occurance of letters------- ");
		for (k = 0; k < a.length; k++) {
			if (a[k][0] != null && a[k][1] != null)
				System.out.println(a[k][0] + " " + a[k][1]);
		}

		System.out.println("--------Sorting------");

		for (l = 0; l < a.length; l++) {
			for (k = 0; k < l - 1; k++) {
				if (a[k][0] != null && a[k][1] != null && a[k + 1][0] != null && a[k + 1][1] != null) {
					if (Integer.parseInt(a[k][1]) > Integer.parseInt(a[k + 1][1])) {
						s = a[k][1];
						a[k][1] = a[k + 1][1];
						a[k + 1][1] = s;

						s = a[k][0];
						a[k][0] = a[k + 1][0];
						a[k + 1][0] = s;
					}

				}
			}
		}

		for (k = 0; k < a.length; k++) {
			if (a[k][0] != null && a[k][1] != null) {
				// System.out.println(k);
				System.out.println(a[k][0] + " " + a[k][1]);
			}
		}

		System.out.println("--------Remove Duplicates------");
		for (l = 0; l <= a.length - 1; l++) {
			l1 = 0;
			if (l != 0) {
				for (k = 0; k < l; k++) {
					if (a[k][0] != null && a[k][1] != null && a[l][0] != null && a[l][1] != null) {
						if (a[l][0].equals(a[k][0])) {
							l1 = 1;
							break;
						}
					}
				}
				if (a[l][0] != null && a[l][1] != null) {
					if (l1 == 0) {
						// System.out.println(a[l][0] + " " + a[l][1]);
						a1[l][0] = a[l][0];
						a1[l][1] = a[l][1];
					}
				}
			}
		}

		for (k = 0; k < a.length; k++) {
			if (a1[k][0] != null && a1[k][1] != null)
				System.out.println(a1[k][0] + " " + a1[k][1]);
		}
		for (k = 0; k < a.length; k++) {
			if (a1[k][0] != null && a1[k][1] != null)
			{
				if(Integer.parseInt(a1[k][1]) < Integer.parseInt(a1[k+1][1]))
				{
					secondLeast =  a1[k+1][1];
					break;
				}
			}
		}
		System.out.println("Second least occuring letters are : ");
		for (k = 0; k < a.length; k++) {
			if (a1[k][0] != null && a1[k][1] != null)
			{
				if(a1[k][1].equals(secondLeast))
					System.out.println(a1[k][0]);
			}
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LeastRepeat leastRepeat = new LeastRepeat();
		leastRepeat.repeat();
	}

}

