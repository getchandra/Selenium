package javaprgms;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.file.FileAlreadyExistsException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileExistsException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

@SuppressWarnings("unused")
public class WrapperMethods {
	RemoteWebDriver driver;
	int i;
	DesiredCapabilities dc;

	//click an element
	//locator is id
	public void clickById(String id) {
		
		try {
			driver.findElement(By.id(id)).click();
		} catch (Exception e) {
			System.out.println("Element not found");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}
	}

	//check element is visible
	//locator is id
	//returns boolean type
	public boolean isVisibleById(String id) throws NoSuchElementException, NullPointerException {
			return driver.findElement(By.id(id)).isDisplayed();
	}
			

	//check element is enabled
	//locator id id
	//returns boolean
	public boolean isEnabledById(String id) throws NoSuchElementException, NullPointerException  {
			return driver.findElement(By.id(id)).isEnabled();	
	}

	//To get text of element 
	//locator is id
	//returns string
	public String getTextById(String id) throws NoSuchElementException, NullPointerException, Exception{
			return driver.findElement(By.id(id)).getText();
	}

	//To enter text in field 
	//locator is id
	public void enterTextById(String id, String Text) {
		try {
			driver.findElement(By.id(id)).clear();
			driver.findElement(By.id(id)).sendKeys(Text);
		} 
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot enter text");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}
	}

	//To clear Text in field
	//locator is id
	public void clearById(String id) {
		try {
			driver.findElement(By.id(id)).clear();
		} 
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot clear text");
			e.printStackTrace();
		}
	}

	//get list of elements
	//locator is id
	//returns a list of webelements
	public List<WebElement> getListofElementsById(String id) throws NoSuchElementException, NullPointerException {
			return driver.findElements(By.id(id));
	}

	//click an element
	//locator is tag name
	public void clickByTagName(String tagname) {
		try {
			driver.findElement(By.tagName(tagname)).click();
		} catch (Exception e) {
			System.out.println("Element not found");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}			
	}

	//check element is visible
	//locator is tag name
	//returns boolean type
	public boolean isVisisbleByTagName(String tagname) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.tagName(tagname)).isDisplayed();
	}


	//check element is enabled
	//locator id tag name
	//returns boolean
	public boolean isEnabledByTagName(String tagname) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.tagName(tagname)).isEnabled();
	}

	//To get text of element 
	//locator is tag name
	//returns string
	public String getTextByTagName(String tagname) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.tagName(tagname)).getText();
	}
	
	//To clear Text in field
	//locator is  tag name
	public void clearByTagName(String tagname) {
		try {
			driver.findElement(By.tagName(tagname)).clear();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot clear text");
			e.printStackTrace();
		}
	}

	//To enter text in field 
	//locator is tag name
	public void EnterTextByTagName(String tagname, String value) {
		try {
			driver.findElement(By.tagName(tagname)).clear();
			driver.findElement(By.tagName(tagname)).sendKeys(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot enter text");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}	
	}

	//get list of elements
	//locator is tag name
	//returns a list of web elements
	public List<WebElement> getListofElementsByTagName(String tagname) throws NoSuchElementException, NullPointerException  {
		return driver.findElements(By.tagName(tagname));
	}
	
	//click an element
	//locator is name
	public void clickByName(String name) {
		try
		{
			driver.findElement(By.name(name)).click();
		}
		catch (Exception e) {
			System.out.println("Element not found");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}	
	}

	//check element is visible
	//locator is name
	//returns boolean type
	public boolean isDisplayedByName(String name) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.name(name)).isDisplayed(); 
	}

	//check element is enabled
	//locator id name
	//returns boolean
	public boolean isEnabledByName(String name) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.name(name)).isEnabled();
	}

	//To get text of element 
	//locator is name
	//returns string
	public String getTextByName(String name) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.name(name)).getText();
	}

	//To clear Text in field
	//locator is  name
	public void clearByName(String name) {
		try{
			driver.findElement(By.name(name)).clear();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot clear text");
			e.printStackTrace();
		}
	}
	
	//To enter text in field 
	//locator is name
	public void enterTextByName(String name, String value) {
		try {
			driver.findElement(By.name(name)).clear();
			driver.findElement(By.name(name)).sendKeys(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot enter text");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}	
	}

	//get list of elements
	//locator is name
	//returns a list of web elements
	public List<WebElement> getListofElementsByName(String name) throws NoSuchElementException, NullPointerException{
		return driver.findElements(By.name(name));
	}

	//click an element
	//locator is class name
	public void clickByClassName(String className) {
		try {
			driver.findElement(By.className(className)).click();
		}
		catch (Exception e) {
			System.out.println("Element not found");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}	
	}
	
	//check element is visible
	//locator is classname
	//returns boolean type
	public boolean isDisplayedByClassName(String className) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.className(className)).isDisplayed();
	}

	//check element is enabled
	//locator is class name
	//returns boolean type
	public boolean isEnabledByClassName(String className) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.className(className)).isEnabled();
	}

	//To get text of element
	//locator is class name
	//returns String
	public String getTextByClassName(String className) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.className(className)).getText();
	}

	//To enter text in field 
	//locator is class name
	public void enterTextByClassName(String className, String value) {
		try {
			driver.findElement(By.className(className)).clear();
			driver.findElement(By.className(className)).sendKeys(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot enter text");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}	
	}

	//To clear text in field 
	//locator is class name
	public void clearByClassName(String className) {
		try {
			driver.findElement(By.className(className)).clear();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot clear text");
			e.printStackTrace();
		}
	}

	//get list of elements
	//locator is class name
	//returns a list of web elements
	public List<WebElement> getListofElementsByClassName(String className) throws NoSuchElementException, NullPointerException {
		return driver.findElements(By.className(className));
	}

	//click an element
	//locator is xpath
	public void clickByxpath(String xpath) {
		try {
			driver.findElement(By.xpath(xpath)).click();
		}
		catch (Exception e) {
			System.out.println("Element not found");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}	
	}

	//check element is visible
	//locator is xpath
	//returns boolean type
	public boolean isDisplayedByxpath(String xpath) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.xpath(xpath)).isDisplayed();
	}

	//check element is enabled
	//locator is xpath
	//returns boolean type
	public boolean isEnabledByxpath(String xpath) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.xpath(xpath)).isEnabled();
	}

	//To get text of element
	//locator is xpath
	//returns String
	public String getTextByxpath(String xpath) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.xpath(xpath)).getText();
	}

	//To enter text in field 
	//locator is xpath
	public void enterTextByxpath(String xpath, String value) {
		try {
			driver.findElement(By.xpath(xpath)).clear();
			driver.findElement(By.xpath(xpath)).sendKeys(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot enter text");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}
	}

	//To clear text in field 
	//locator is xpath
	public void clearByxpath(String xpath) {
		try {
			driver.findElement(By.xpath(xpath)).clear();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot clear text");
			e.printStackTrace();
		}
	}

	//get list of elements
	//locator is xpath
	//returns a list of web elements
	public List<WebElement> getListofElementsByXpath(String xpath) throws NoSuchElementException, NullPointerException {
		return driver.findElements(By.xpath(xpath));
	}

	//click an element
	//locator is css
	public void clickByCss(String css) {
		try {
			driver.findElement(By.cssSelector(css)).click();
		}
		catch (Exception e) {
			System.out.println("Element not found");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}
	}

	//check element is visible
	//locator is css
	//returns boolean type
	public boolean isDisplayedByCss(String css) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.cssSelector(css)).isDisplayed();
	}

	//check element is enabled
	//locator is css
	//returns boolean type
	public boolean isEnabledByCss(String css) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.cssSelector(css)).isEnabled();
	}

	//get text of an element
	//locator is css
	//returns String
	public String getTextByCss(String css) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.cssSelector(css)).getText();
	}

	//Enter text by css
	//locator is css
	public void enterTextByCss(String css, String value) {
		try {
			driver.findElement(By.xpath(css)).clear();
			driver.findElement(By.cssSelector(css)).sendKeys(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot enter text");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}
	}

	//clear text by css
	//locator is css
	public void clearByCss(String css) {
		try {
			driver.findElement(By.cssSelector(css)).clear();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("cannot clear text");
			e.printStackTrace();
		}
	}

	//get list of elements
	//locator is css
	//returns a list of web elements
	public List<WebElement> getListofElementsByCss(String css) throws NoSuchElementException, NullPointerException{
		return  driver.findElements(By.cssSelector(css));	
	}

	//click an element
	//locator is partial Link Text
	public void clickByPartialLinkText(String partialLinkText) {
		try {
			driver.findElement(By.partialLinkText(partialLinkText)).click();
		}
		catch (Exception e) {
			System.out.println("Element not found");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}
	}

	//check element is visible
	//locator is partial link text
	//returns boolean
	public boolean isDisplayedByPartialLinkText(String partialLinkText) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.partialLinkText(partialLinkText)).isDisplayed();
	}

	//check element is enabled
	//locator is partial link text
	//returns boolean
	public boolean isEnabledByPartialLinkText(String partialLinkText) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.partialLinkText(partialLinkText)).isEnabled();
	}

	//get text of an element
	//locator is partial link text
	//returns String
	public String getTextByPartialLinkText(String partialLinkText) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.partialLinkText(partialLinkText)).getText();
	}

	//get list of elements
	//locator is partial link text
	//returns a list of web elements
	public List<WebElement> getListofElementsByPartialLinkText(String partialLinkText) throws NoSuchElementException, NullPointerException {
		return driver.findElements(By.partialLinkText(partialLinkText));
	}

	//click an element
	//locator is link Text
	public void clickByLinkText(String linktext) {
		try {
			driver.findElement(By.linkText(linktext)).click();
		}
		catch (Exception e) {
			System.out.println("Element not found");
			e.printStackTrace();
		}
		finally {
			snapshot();
		}
	}

	//check element is visible
	//locator is link text
	//returns boolean
	public boolean isDisplayedByLinkText(String linktext) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.linkText(linktext)).isDisplayed();
	}
	
	//check element is enabled
	//locator is link text
	//returns boolean
	public boolean isEnabledByLinkText(String linktext) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.linkText(linktext)).isEnabled();
	}

	//get text of element
	//locator is link text
	//returns boolean
	public String getTextByLinkText(String linktext) throws NoSuchElementException, NullPointerException {
		return driver.findElement(By.linkText(linktext)).getText();
	}

	//get list of elements
	//locator is link text
	//returns a list of web elements
	public List<WebElement> getListofElementsByLinkText(String linkText) throws NoSuchElementException, NullPointerException {
		List<WebElement> webElements = driver.findElements(By.linkText(linkText));
		return webElements;
	}

	//verify the title
	//return boolean
	public boolean verifyTitle(String title) {
		try {
			return driver.getTitle().equals(title);
		}
		catch(Exception e){
			System.out.println("Title not matching");
			return false;                         //this line will not execute anytime
		}
	}

	//verify the url
	//return boolean
	public boolean verifyURL(String url) {
		try {
			return driver.getCurrentUrl().equals(url);
		}
		catch(Exception e){
			System.out.println("Url not matching");
			return false;                         //this line will not execute anytime
		}
	}

	//get page url
	//return String
	public String getURL(String url) throws NoSuchElementException, NullPointerException {
		return driver.getCurrentUrl();
	}

	//open the driver
	public void openApp(String browser, String url) {
		try {
			if (browser.equalsIgnoreCase("firefox"))
				driver = new FirefoxDriver();
			else if (browser.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "driver\\chromedriver.exe");
				driver = new ChromeDriver();
			}
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(url);
		}
		catch(NullPointerException e)
		{
			System.out.println("driver not initiated");
		}
		catch(TimeoutException e)
		{
			System.out.println("Time out Exception");
		}
		catch(Exception e)
		{
			System.out.println("Error in opening browser and loading URL");
		}
		finally 
		{
			snapshot();
		}
	}

	//close the driver
	public void closeApp() {
		try {
			driver.close();
		}
		catch(Exception e)
		{
			System.out.println("Error in closing the driver");
		}
	}

	//check checkbox checked or not
	//locator id 
	//returns boolean
	public boolean isCheckedById(String id) {
		try {
			return driver.findElement(By.id(id)).isSelected();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Error in checking checkbox");
			e.printStackTrace();
			return false;
		}
	}

	//check checkbox checked or not
	//locator xpath 
	//returns boolean
	public boolean isCheckedByXpath(String xpath) {
		try {
			return driver.findElement(By.xpath(xpath)).isSelected();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Error in checking checkbox");
			e.printStackTrace();
			return false;
		}
	}

	//check checkbox checked or not
	//locator name 
	//returns boolean
	public boolean isCheckedByName(String name) {
		try {
			return driver.findElement(By.name(name)).isSelected();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Error in checking checkbox");
			e.printStackTrace();
			return false;
		}
	}

	//check checkbox checked or not
	//locator class name 
	//returns boolean
	public boolean isCheckedByClassName(String className) {
		try {
			return driver.findElement(By.className(className)).isSelected();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Error in checking checkbox");
			e.printStackTrace();
			return false;
		}
	}

	//check checkbox checked or not
	//locator css 
	//returns boolean
	public boolean isCheckedByCss(String css) {
		try {
			return driver.findElement(By.cssSelector(css)).isSelected();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Error in checking checkbox");
			e.printStackTrace();
			return false;
		}
	}

	//check checkbox checked or not
	//locator tag name 
	//returns boolean
	public boolean isCheckedByTagName(String tagname) {
		try {
			return driver.findElement(By.tagName(tagname)).isSelected();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Error in checking checkbox");
			e.printStackTrace();
			return false;
		}
	}

	//select by visible text in a dropdown
	//locator is id
	public void selectByVisibleTextById(String id, String text) {
		try {
			Select dropdown = new Select(driver.findElement(By.id(id)));
			dropdown.selectByVisibleText(text);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
		
	}

	//select by visible text in a dropdown
	//locator is name
	public void selectByVisibleTextByName(String name, String text) {
		try {
			Select dropdown = new Select(driver.findElement(By.name(name)));
			dropdown.selectByVisibleText(text);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by visible text in a dropdown
	//locator is class name
	public void selectByVisibleTextByClassName(String className, String text) {
		try {
			Select dropdown = new Select(driver.findElement(By.name(className)));
			dropdown.selectByVisibleText(text);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by visible text in a dropdown
	//locator is xpath
	public void selectByVisibleTextByxpath(String xpath, String text) {
		try {
			Select dropdown = new Select(driver.findElement(By.xpath(xpath)));
			dropdown.selectByVisibleText(text);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}

	}

	//select by visible text in a dropdown
	//locator is css
	public void selectByVisibleTextByCss(String css, String text) {
		try {
			Select dropdown = new Select(driver.findElement(By.cssSelector(css)));
			dropdown.selectByVisibleText(text);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by visible text in a dropdown
	//locator is tag name
	public void selectByVisibleTextByTagName(String tagName, String text) {
		try {
			Select dropdown = new Select(driver.findElement(By.tagName(tagName)));
			dropdown.selectByVisibleText(text);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by Index in a dropdown
	//locator is id
	public void selectByIndexById(String id, int index) {
		try {
			Select dropdown = new Select(driver.findElement(By.id(id)));
			dropdown.selectByIndex(index);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by Index in a dropdown
	//locator is name
	public void selectByIndexByName(String name, int index) {
		try {
			Select dropdown = new Select(driver.findElement(By.name(name)));
			dropdown.selectByIndex(index);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by Index in a dropdown
	//locator is classname
	public void selectByIndexByClassName(String className, int index) {
		try {
			Select dropdown = new Select(driver.findElement(By.name(className)));
			dropdown.selectByIndex(index);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by Index in a dropdown
	//locator is xpath
	public void selectByIndexByxpath(String xpath, int index) {
		try {
			Select dropdown = new Select(driver.findElement(By.xpath(xpath)));
			dropdown.selectByIndex(index);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by Index in a dropdown
	//locator is css
	public void selectByIndexByCss(String css, int index) {
		try {
			Select dropdown = new Select(driver.findElement(By.cssSelector(css)));
			dropdown.selectByIndex(index);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by Index in a dropdown
	//locator is tag name
	public void selectByIndexByTagName(String tagName, int index) {
		try {
			Select dropdown = new Select(driver.findElement(By.tagName(tagName)));
			dropdown.selectByIndex(index);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by value in a dropdown
	//locator is id
	public void selectByValueById(String id, String value) {
		try {
			Select dropdown = new Select(driver.findElement(By.id(id)));
			dropdown.selectByValue(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by value in a dropdown
	//locator is name
	public void selectByValueByName(String name, String value) {
		try {
			Select dropdown = new Select(driver.findElement(By.name(name)));
			dropdown.selectByValue(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}

	}

	//select by value in a dropdown
	//locator is classname
	public void selectByValueByClassName(String className, String value) {
		try {
			Select dropdown = new Select(driver.findElement(By.name(className)));
			dropdown.selectByValue(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by value in a dropdown
	//locator is xpath
	public void selectByValueByxpath(String xpath, String value) {
		try {
			Select dropdown = new Select(driver.findElement(By.xpath(xpath)));
			dropdown.selectByValue(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by value in a dropdown
	//locator is css
	public void selectByValueByCss(String css, String value) {
		try {
			Select dropdown = new Select(driver.findElement(By.cssSelector(css)));
			dropdown.selectByValue(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//select by value in a dropdown
	//locator is tag name
	public void selectByValueByTagName(String tagName, String value) {
		try {
			Select dropdown = new Select(driver.findElement(By.tagName(tagName)));
			dropdown.selectByValue(value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element not found");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in selecting dropdown value");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}

	}

	//switch To Alert
	public void switchToAlert() {
		try {
			driver.switchTo().alert();
		}
		catch(NoAlertPresentException e)
		{
			System.out.println("No alert Present");
		}
		catch(Exception e)
		{
			System.out.println("Error in hndling alerts!");
		}
		finally
		{
			snapshot();
		}
	}

	//accept the Alert
	public void acceptAlert() {
		try {
			driver.switchTo().alert().accept();;
		}
		catch(NoAlertPresentException e)
		{
			System.out.println("No alert Present");
		}
		catch(Exception e)
		{
			System.out.println("Error in hndling alerts!");
		}
		finally
		{
			snapshot();
		}
	}

	//dismiss the Alert
	public void dismissAlert() {
		try {
			driver.switchTo().alert().dismiss();;
		}
		catch(NoAlertPresentException e)
		{
			System.out.println("No alert Present");
		}
		catch(Exception e)
		{
			System.out.println("Error in hndling alerts!");
		}
		finally
		{
			snapshot();
		}
	}

	//get the Alert text
	public String getTextFromAlert() {
		try {
			return driver.switchTo().alert().getText();
		}
		catch(NoAlertPresentException e)
		{
			System.out.println("No alert Present");
			e.printStackTrace();
			return "no text";						//line will not execute
		}
		catch(Exception e)
		{
			System.out.println("Error in hndling alerts!");
			e.printStackTrace();
			return "no text";
		}
		
	}

	//send text to Alert box and accept
	public void sendTextToAlertAndAccept(String text) {
		try {
			driver.switchTo().alert().sendKeys(text);
			driver.switchTo().alert().accept();
		}
		catch(NoAlertPresentException e)
		{
			System.out.println("No alert Present");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in hndling alerts!");
			e.printStackTrace();
		}
		
	}

	//send text to Alert box and dismiss
	public void sendTextToAlertAndDismiss(String text) {
		try {
			driver.switchTo().alert().sendKeys(text);
			driver.switchTo().alert().dismiss();
		}
		catch(NoAlertPresentException e)
		{
			System.out.println("No alert Present");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Error in hndling alerts!");
			e.printStackTrace();
		}
		finally
		{
			snapshot();
		}
	}

	//switch to primary window
	public void switchToPrimaryWindow() {
		try {
			Set<String> windows = driver.getWindowHandles();
			for (String s : windows) {
				driver.switchTo().window(s);
				break;
			}
		}
		catch(NoSuchWindowException e)
		{
			System.out.println("cannot switch to primary window");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to primary window");
			e.printStackTrace();
		}
		
	}

	//switch to last window
	public void switchToLastWindow() {
		try {
			Set<String> windows = driver.getWindowHandles();
			for (String s : windows) {
				driver.switchTo().window(s);
			}
		}
		catch(NoSuchWindowException e)
		{
			System.out.println("cannot switch to last window");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to last window");
			e.printStackTrace();
		}
	}

	//get current window name
	public String currentWindowName() {
		try {
			String currentWindow = driver.getWindowHandle();
			System.out.println("current Window : " + currentWindow);
			return currentWindow;
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to last window");
			e.printStackTrace();
			return "no windows" ;
		}
	}

	//switch to frame
	//locator id
	public void switchToFrameById(String id) {
		try {
			driver.switchTo().frame(driver.findElement(By.id(id)));
		}
		catch(NoSuchFrameException e)
		{
			System.out.println("No such Frame");
			e.printStackTrace();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No such Element");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to frame");
			e.printStackTrace();
		}
	}

	//switch to frame
	//locator className
	public void switchToFrameByClassName(String className) {
		try {
			driver.switchTo().frame(driver.findElement(By.className(className)));
		}
		catch(NoSuchFrameException e)
		{
			System.out.println("No such Frame");
			e.printStackTrace();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No such Element");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to frame");
			e.printStackTrace();
		}
	}

	//switch to frame
	//locator Name
	public void switchToFrameByName(String name) {
		try {
			driver.switchTo().frame(driver.findElement(By.name(name)));
		}
		catch(NoSuchFrameException e)
		{
			System.out.println("No such Frame");
			e.printStackTrace();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No such Element");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to frame");
			e.printStackTrace();
		}
	}

	//switch to frame
	//locator xpath
	public void switchToFrameByXpath(String xpath) {
		try {
			driver.switchTo().frame(driver.findElement(By.xpath(xpath)));
		}
		catch(NoSuchFrameException e)
		{
			System.out.println("No such Frame");
			e.printStackTrace();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No such Element");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to frame");
			e.printStackTrace();
		}
	}

	//switch to frame
	//locator Css
	public void switchToFrameByCss(String css) {
		try {
			driver.switchTo().frame(driver.findElement(By.cssSelector(css)));
		}
		catch(NoSuchFrameException e)
		{
			System.out.println("No such Frame");
			e.printStackTrace();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No such Element");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to frame");
			e.printStackTrace();
		}
	}

	//switch to frame
	//locator linkText
	public void switchToFrameByLinkText(String linkText) {
		try {
			driver.switchTo().frame(driver.findElement(By.linkText(linkText)));
		}
		catch(NoSuchFrameException e)
		{
			System.out.println("No such Frame");
			e.printStackTrace();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No such Element");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to frame");
			e.printStackTrace();
		}
	}

	//switch to frame
	//locator partial link Text
	public void switchToFrameByPartialLinkText(String partialLinkText) {
		try {
			driver.switchTo().frame(driver.findElement(By.partialLinkText(partialLinkText)));
		}
		catch(NoSuchFrameException e)
		{
			System.out.println("No such Frame");
			e.printStackTrace();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No such Element");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to frame");
			e.printStackTrace();
		}
	}

	//switch to frame
	//locator tag name
	public void switchToFrameByTagName(String tagname) {
		try {
			driver.switchTo().frame(driver.findElement(By.tagName(tagname)));
		}
		catch(NoSuchFrameException e)
		{
			System.out.println("No such Frame");
			e.printStackTrace();
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No such Element");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("cannot switch to frame");
			e.printStackTrace();
		}
	}

	//switch to defaultContent
	public void switchDefaultContent() {
		driver.switchTo().defaultContent();
	}

	//compares two strings
	//returns boolean
	public boolean stringCompare(String string1,String string2)
	{
		return (string1.equals(string2));
	}
	
	
	//taking screenshot
	public void snapshot()
	{
		try
		{
			File snapshot = driver.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(snapshot,new File("D:\\Eclipse\\TestLeaf\\Sscreenshots\\snapshot " + i++ + ".jpeg"));
		}
		catch(FileNotFoundException e)
		{
			System.out.println("No file found");
			e.printStackTrace();
		}
		catch(NullPointerException e)
		{
			System.out.println("Error in taking screenshot");
			e.printStackTrace();
		}
		catch(FileExistsException ex)
		{
			System.out.println("Error in taking screenshot");
			ex.printStackTrace();
		}
		catch(IOException e1)
		{
			System.out.println("Error in screenshot");
			e1.printStackTrace();
		}
		
	}
	
	//open the Remote driver
	public void openRemoteApp(String browser, Platform platform,String hubUrl,String webUrl) {
		try {
				dc = new DesiredCapabilities();
				dc.setBrowserName(browser);
				dc.setPlatform(platform);
				driver = new RemoteWebDriver(new URL(hubUrl), dc);
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.get(webUrl);
		}
		catch(NullPointerException e)
		{
			System.out.println("driver not initiated");
		}
		catch(TimeoutException e)
		{
			System.out.println("Time out Exception");
		}
		catch(Exception e)
		{
			System.out.println("Error in opening browser and loading URL");
		}
		finally 
		{
			snapshot();
		}
	}
}

