package javaprgms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Prime {
int input;
	
	public void input() throws NumberFormatException, IOException
	{
		System.out.println("Enter the number : ");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		input= Integer.parseInt(br.readLine());
		System.out.println("Entered Number is : " +input);		
		
	}
	
	public void prime()
	{
		int a=0;
		for(int i=2;i<input;i++)
		{
			if(input%i==0)
			{
				a=1;
				break;
			}
		}
		if(a==0)
			System.out.println("Prime");
		else
			System.out.println("Not a prime");
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		Prime p = new Prime();
		p.input();
		p.prime();
	}

}

