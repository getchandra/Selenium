package javaprgms;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@SuppressWarnings("unused")
public class ExcelAcions {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws IOException 
	 */
	
	@SuppressWarnings("resource")
	public void writeExcel() throws IOException
	{
		FileInputStream fis = new FileInputStream(new File("Test.xlsx")); 
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		for(int i=0;i<=4;i++) {
			XSSFRow row = sheet.createRow(i);
			for(int j=0;j<=4;j++) {
				XSSFCell cell= row.createCell(j);
				cell.setCellValue("Row" + i + "col" + j);
			}
		}
		FileOutputStream fos = new FileOutputStream(new File("Test.xlsx")); 
		workbook.write(fos);
		fis.close();
	}
	
	@SuppressWarnings({ "unchecked", "resource" })
	public void readExcel() throws IOException
	{
		FileInputStream fis = new FileInputStream(new File("Test.xlsx")); 
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		ArrayList<String>[][] list = new ArrayList[10][10];
		for(int i=0;i<=4;i++) {
			XSSFRow row = sheet.getRow(i);
			for(int j=0;j<=4;j++) {
				XSSFCell cell= row.getCell(j);
				list[i][j] = new ArrayList<String>();
				list[i][j].add(cell.getStringCellValue());
			}
		}
		for(int i=0;i<=4;i++) {
			for(int j=0;j<=4;j++) {
				System.out.print("Row" + i + "col" + j + " value is : " + list[i][j]);
			}
			System.out.println();
		}
		
		fis.close();
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		ExcelAcions excel = new ExcelAcions();
		excel.writeExcel();
		excel.readExcel();
	}

}
