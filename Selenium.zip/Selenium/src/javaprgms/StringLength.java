package javaprgms;

public class StringLength {

	public void method1(String s) {
		String[] s1 = s.split("");
		System.out.println("Length of the String in method1 : " + s1.length);
	}

	public void method2(String s) {
		int i = 0;
		try {

			while (true) {
				s.substring(0, ++i);
			}
		} catch (Exception e) {
			System.out.println("Length of the String in method2 : " + (i - 1));
		}

	}

	public void method3(String s) {
		int i = 0;
		try {
			while (true) {
				s.charAt(i++);
			}
		} catch (Exception e) {
			System.out.println("Length of the String in method3 : " + (i - 1));
		}
	}

	public static void main(String[] args) {

		StringLength stringLen = new StringLength();
		stringLen.method1("Hello World ");
		stringLen.method2("Hello World ");
		stringLen.method3("Hello World ");
	}

}
