package javaprgms;

import org.openqa.selenium.Platform;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class CreateLead {
	WrapperMethods wrapperMethods = new WrapperMethods();
  @Test
  public void f() {
	  wrapperMethods.enterTextById("username","DemoCSR");
	  wrapperMethods.enterTextById("password","crmsfa");
	  wrapperMethods.clickByClassName("decorativeSubmit");
	  wrapperMethods.clickByxpath("//div[@id='label']/a");
	  wrapperMethods.clickByLinkText("Create Lead");
	  wrapperMethods.enterTextById("createLeadForm_companyName","xxxxxxxxxx");
	  wrapperMethods.enterTextById("createLeadForm_firstName","xxxxxxxxxx");
	  wrapperMethods.enterTextById("createLeadForm_lastName","xxxxxxxxxx");
	  wrapperMethods.clickByClassName("smallSubmit");	  
  }
  @BeforeClass
  public void beforeClass() {
	  wrapperMethods.openRemoteApp("firefox",Platform.WINDOWS,"http://10.85.254.172:4444/wd/hub","http://demo1.opentaps.org/");
  }

  @AfterClass
  public void afterClass() {
	  wrapperMethods.closeApp();
  }

}

