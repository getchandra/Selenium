package javaprgms;

public class RepeatChar {
	String s;
	char c;
	Character[] c1 = new Character[50];
	int occurance, times, highestNum, j;

	public void repeat() {
		s = "cognizant chennai";
		for (int i = 0; i < s.length(); i++) {
			times = 0;
			c = s.charAt(i);
			occurance = s.indexOf(c, 0);

			while (occurance != -1) {
				times = times + 1;
				occurance = s.indexOf(c, occurance + 1);
			}
			System.out.println("Occurance of " + c + " is " + times + " times");
			if (highestNum < times) {
				highestNum = times;
				for (int i1 = 0; i1 < c1.length; i1++) {
					c1[i1] = null;
					j = 0;
				}
				c1[j] = c;

			}
			if (highestNum == times) {
				j = 0;
				for (int i1 = 0; i1 < c1.length; i1++) {
					if (c1[i1] != null) {
						j = j + 1;
						if (c1[i1].equals(c))
							break;
						else
							c1[j] = c;
					}
				}

			}
		}
		System.out.println("Character that occurs max times : ");
		for (int i1 = 0; i1 < c1.length; i1++) {
			if (c1[i1] != null)
				System.out.println(c1[i1]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RepeatChar repeat = new RepeatChar();
		repeat.repeat();
	}

}
