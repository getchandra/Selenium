package javaprgms;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver;
		driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("http://www.popuptest.com/");
		
		//click the link
	    driver.findElement(By.linkText("Multi-PopUp Test #2")).click();
	    
	    //waits till the process gets 100% in the page
	    Thread.sleep(10000);
	    
	    //save the parent window name
	    String parentWindow = driver.getWindowHandle();	
	    System.out.println(parentWindow);
	    
	   // get all the windows
	    Set<String> windows=driver.getWindowHandles();
	   
	    for(String s:windows)
	    {
	    	System.out.println(s);
	    	break;
	    }
	}

}

