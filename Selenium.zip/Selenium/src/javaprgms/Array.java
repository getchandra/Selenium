package javaprgms;

public class Array {
	
	int[] a = {2,3,3,4,2};
	int[] b;
	
	public void array()
	{
		
		for(int i=0;i<=4;i++)
		{
			b[i]=a[i];
			System.out.println(b[i]);
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Array a1 = new Array();
		a1.array();
	}

}

