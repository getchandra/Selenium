package javaprgms;

public class ArrayDuplicate {

	static int[] a = new int[10];

	public void duplicates() {
		int i, j, k;
		a[0] = 1;
		a[2] = 1;
		a[6] = 1;
		a[5] = 2;
		a[1] = 2;
		a[3] = 3;
		a[4] = 8;
		a[7] = 8;
		a[8] = 10;
		a[9] = 3;

		for (i = 0; i <= a.length - 1; i++) {
			k = 0;
			if (i != 0) {
				for (j = 0; j < i; j++) {
					if (a[j] == a[i]) {
						k = 1;
						break;
					}
				}
			}
			if (k == 0)
				System.out.println(a[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayDuplicate array = new ArrayDuplicate();
		array.duplicates();
	}
}
