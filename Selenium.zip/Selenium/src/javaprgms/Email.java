package javaprgms;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Email {

	private String email = "a5678a@gmail.com";
	List<String> emailList;

	public void validation() {
		emailList = new LinkedList<String>();
		for (String s : email.split("@"))
			emailList.add(s);
		for (String s : emailList.get(1).split("\\.")) {
			emailList.add(s);
		}
		emailList.remove(1);
		for (String s : emailList)
			System.out.println(s);

		if (name() && domain()) {
			if(emailList.get(2).equals("in") || emailList.get(2).equals("com"))
				System.out.println("email valid");
			else
				System.out.println("Email invlid");
		} else
			System.out.println("email invalid!");

	}

	public boolean checkPattern() {
		if (email.indexOf("@") >= 0 && email.indexOf(".") >= 0)
			return true;
		else
			return false;
	}

	public boolean name() {

		int length = emailList.get(0).length() - 1;
		int i = 0, j = 0, k = 0, l = 0, m = 0;
		// cant be only numbers i=1
		Pattern pattern = Pattern.compile("[^\\d{1," + length + "}]");
		Matcher matcher = pattern.matcher(emailList.get(0));
		while (matcher.find()) {
			i = 1;
			// System.out.print(matcher.group());
		}
		// no special chars except "_" j=0
		pattern = Pattern.compile("\\W_{0,}");
		matcher = pattern.matcher(emailList.get(0));
		while (matcher.find()) {
			j = 1;
		}

		// should not start with number

		pattern = Pattern.compile("[\\w && [^\\d]]\\d");
		matcher = pattern.matcher(emailList.get(0));
		while (matcher.find()) {
			k = 1;
		}

		pattern = Pattern.compile("\\@{1,1}");
		matcher = pattern.matcher(email);
		while (matcher.find()) {
			l = l + 1;
		}

		pattern = Pattern.compile("\\.{1,1}");
		matcher = pattern.matcher(email);
		while (matcher.find()) {
			m = m + 1;
		}

		if (i == 1 && j == 0 && k == 1 && l == 1 && m == 1)
			return true;
		else
			return false;
	}

	public boolean domain() {
		int i=0,j=0;
		Pattern pattern = Pattern.compile("[\\d]");
		Matcher matcher = pattern.matcher(emailList.get(1));
		while(matcher.find())
		{
			i=i+1;
		}
		pattern = Pattern.compile("[\\d\\W]");
		matcher = pattern.matcher(emailList.get(1));
		while(matcher.find())
		{
			j=j+1;
			
		}
		if(i==0 && j==0)
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Email email1 = new Email();
		if (email1.checkPattern())
			email1.validation();
		
	}

}

