package javaprgms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Fact {
	int input;
	
	public void input() throws NumberFormatException, IOException
	{
		System.out.println("Enter the number : ");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		input= Integer.parseInt(br.readLine());
		System.out.println("Entered Number is : " +input);		
		
	}
	
	public void fact()
	{
		int a=1;
		for(int i=1;i<=input;i++)
		{
			a=a*i;
			System.out.print(i + " ");
		}
		System.out.println();
		System.out.println(a);
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		Fact f=new Fact();
		f.input();
		f.fact();
	}

}
