package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class IRCTCSignup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://irctc.co.in");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.findElementByLinkText("Sign up").click();
		driver.manage().window().maximize();
		driver.findElementByName("userName").sendKeys("scsvirctc");
		driver.findElementByName("question").sendKeys("What is your pets name?");
		driver.findElementByName("answer").sendKeys("Jimmy");
		driver.findElementByName("firstName").sendKeys("Chandrasekhara");
		driver.findElementByName("lastName").sendKeys("Varma");
		driver.findElementByName("gender").sendKeys("Male");
		driver.findElementByName("maritalStatus").sendKeys("Married");
		driver.findElementByName("day").sendKeys("05");
		driver.findElementByName("month").sendKeys("Jun");
		driver.findElementByName("year").sendKeys("1984");
		

	}

}
