package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class CreateLeadInOpenTaps {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://demo1.opentaps.org");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.findElementById("username").sendKeys("DemoCSR");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByXPath("//*[@id='button']/a/img").click();
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementById("createLeadForm_companyName").sendKeys("Steria");
		driver.findElementById("createLeadForm_firstName").sendKeys("Chandrasekhara");
		driver.findElementById("createLeadForm_lastName").sendKeys("Varma");
		driver.findElementByName("submitButton").click();
//		Verify the text
		driver.findElementByLinkText("Logout").click();
		driver.close();
	}

}
