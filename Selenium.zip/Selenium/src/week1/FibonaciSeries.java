package week1;

public class FibonaciSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=0;
int b=1;
int c;
System.out.println(a);
System.out.println(b);

do  
{
      c = a + b;
      System.out.println(c);
    
       a = b;
       b = c;
     
}
while(b<=100);
		
		
	}

}
