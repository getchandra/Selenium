package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class GmailLoginUsingWebDriver {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://www.gmail.com");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.manage().window().maximize();
//		driver.findElementById("gmail-sign-in").click();
		driver.findElementById("Email").sendKeys("getchandra.ssn@gmail.com");
		driver.findElementById("next").click();
		driver.findElementById("Passwd").sendKeys("Mar21_1984");
//		driver.findElementById("PersistentCookie").click();
		driver.findElementById("signIn").click();
		driver.findElementByXPath("//*[@id='gb']/div[1]/div[1]/div[2]/div[4]/div[1]/a/span").click();
		driver.findElementByLinkText("Sign out").click();
		driver.close();
	}

}
