package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class OpenTabsLoginusingWebDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Open the Chrome browse
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		
//		System.setProperty("webdriver.ie.driver", "C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\IEDriverServer.exe");
//		IEDriverServer driver=new ieDriver();
				
		driver.get("http://demo1.opentaps.org/");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		String text = driver.findElementByXPath("//*[@id='form']/h2").getText();
		String url = driver.getCurrentUrl();
		System.out.println(url);
		String title = driver.getTitle();
		System.out.println(title);
		System.out.println(text);
		
			if(text.contains("Demo Sales Manager"))
					{
			System.out.println("Pass");
					}
			else{
				System.out.println("Fail");
			}
driver.findElementByClassName("decorativeSubmit").click();
driver.close();
	}

}
