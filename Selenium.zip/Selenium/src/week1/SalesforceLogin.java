package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class SalesforceLogin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://developer.force.com");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.findElementById("login-button").click();
		driver.manage().window().maximize();
		driver.findElementById("username").sendKeys("getchandra.ssn@gmail.com");
		driver.findElementById("password").sendKeys("scs.varma84");
		driver.findElementById("Login").click();
		driver.findElementById("oaapprove").click();
//		driver.findElementByClassName("ellipsis").click();
//		driver.findElementById("user-info-logout").click();

	}

}
