package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class SalesforceSignUP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://developer.force.com");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.findElementByLinkText("Sign Up �").click();
		driver.manage().window().maximize();
		driver.findElementById("first_name").sendKeys("Chandrasekhara");
		driver.findElementById("last_name").sendKeys("Varma");
		driver.findElementById("email").sendKeys("getchandra.ssn@gmail.com");
		driver.findElementById("job_role").sendKeys("Administrator");
		driver.findElementById("company").sendKeys("ABC");
		driver.findElementByClassName("textFieldOp").sendKeys("India");
		driver.findElementById("postal_code").sendKeys("603103");
		driver.findElementById("username").sendKeys("getchandra.ssn@gmail.com");
		driver.findElementById("eula").click();
		driver.findElementById("submit_btn").click();
		driver.findElementByLinkText("Getting Started page").click();
	}

}
