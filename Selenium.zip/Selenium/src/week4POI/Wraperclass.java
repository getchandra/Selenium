package week4POI;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Wraperclass {
	WebDriver driver;

	public void launchBrowser(String browser, String url)
	{
		if (browser.equalsIgnoreCase("chrome"));			
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.get(url);
	}
	
	public void enterById(String id){
	driver.findElement(By.id(id)).clear();
	driver.findElement(By.id(id)).sendKeys(id);
	}
	public void clickById(String id){
		driver.findElement(By.id(id)).click();
	}
	public void clickByLinkText(String id){
		driver.findElement(By.linkText(id)).click();
		
	}
	public void closeBrowser(String id){
		driver.close();
	}
}
