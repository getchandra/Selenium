package week4POI;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

@SuppressWarnings("unused")
public class Snapshot {
	static int i;

	public static void main(String[] args) throws IOException {
		

//		System.setProperty("webdriver.chrome.driver",
//				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
//		ChromeDriver driver = new ChromeDriver();
		FirefoxDriver driver = new FirefoxDriver();
		driver.get("http://www.google.com");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		File snapshot = driver.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(snapshot, new File("D:\\SELENIUM\\Selenium\\data\\Snap"+ i++ +".JPEG"));
		
	}

}
