package week4POI;

public class FacebookLogin {

	public static void main(String[] args) {

		Wraperclass wc = new Wraperclass();
		wc.launchBrowser("chrome", "https://www.facebook.com");
		wc.enterById("getchandra.ssn@gmail.com");
		wc.enterById("mar21_1984");
		wc.clickByLinkText("submit");
		
	}

}
