package week2;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleNameSearch {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.google.co.in");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.findElementByName("q").sendKeys("Chandra");
		driver.findElementByName("btnG").click();
		Thread.sleep(5000);
		List<WebElement> allNames = driver.findElementsByTagName("a");
		Thread.sleep(5000);
		System.out.println(allNames.size());
		int count = 0;
		for (int i = 1; i <= allNames.size() - 1; i = i + 1) {
			String a = allNames.get(i).getText();
			if (a.contains("Chandra")) {
				count = count + 1;
				System.out.println(allNames.get(i).getText());
			}
		}
		System.out.println(count);
//		driver.close();
	}
}
