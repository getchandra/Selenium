package week2;

import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;

public class PopupsClose {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://popuptest.com");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.findElementByLinkText("Multi-PopUp Test").click();
		Thread.sleep(5000);
		String parentWindow = driver.getWindowHandle();
		System.out.println(parentWindow);
		Set<String> windows = driver.getWindowHandles();
		for (String popUp : windows) {
			if (!popUp.equalsIgnoreCase(parentWindow)) {
				driver.switchTo().window(popUp);
				driver.close();
			}
		}
		System.out.println(driver.switchTo().window(parentWindow).getTitle());
		driver.close();
	}
}
