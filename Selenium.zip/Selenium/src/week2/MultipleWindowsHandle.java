package week2;

import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.Select;
//      import org.apache.bcel.generic.Select;
import org.openqa.selenium.chrome.ChromeDriver;
import com.thoughtworks.selenium.webdriven.commands.GetText;

@SuppressWarnings("unused")
public class MultipleWindowsHandle {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.crystalcruises.com");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
//		String Parent_Window= driver.getWindowHandle();
		driver.findElementByLinkText("GUEST CHECK-IN").click();
		Set<String> WinHandle1= driver.getWindowHandles();
    	for (String Child_Window1 : WinHandle1)
		{
    		System.out.println(Child_Window1);
    		driver.switchTo().window(Child_Window1);
		}
			driver.findElementByLinkText("click here").click();
			Set<String> WinHandle2= driver.getWindowHandles();
			for (String Child_Window2 : WinHandle2)
			{
				driver.switchTo().window(Child_Window2);

			}
			Select dropdown = new Select (driver.findElementByClassName("goog-te-combo"));
			dropdown.selectByValue("ta");
			Thread.sleep(2000);
			System.out.println("Title of the page after translation " + driver.getTitle());
			
			driver.switchTo().frame(":1.container");
//			System.out.println (driver.findElementByLinkText("Tamil")).getText();
//			driver.quit();
		
			
		}
		
}




