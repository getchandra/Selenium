package week2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

@SuppressWarnings("unused")
public class Jquery {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.jqueryui.com");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.findElementByLinkText("Draggable").click();
		List <WebElement> allFrames=driver.findElementsByTagName("iframe");
		System.out.println("Total frames:"+allFrames.size());
		Thread.sleep(3000);
		driver.switchTo().frame(driver.findElementByClassName("demo-frame"));
		String textFrame=driver.findElementByTagName("p").getText();
		System.out.println(textFrame);
		driver.switchTo().defaultContent();
		driver.findElementByLinkText("Droppable").click();
		driver.close();
				
	}

}
