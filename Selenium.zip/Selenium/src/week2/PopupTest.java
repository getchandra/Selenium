package week2;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class PopupTest {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://popuptest.com");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.findElementByLinkText("Multi-PopUp Test").click();
		Thread.sleep(5000);
		String parWindow = driver.getWindowHandle();

		Set<String> popups = driver.getWindowHandles();
		driver.getTitle();
		System.out.println(parWindow);
		{
			Iterator<String> itr = popups.iterator();
			while (itr.hasNext()) {

				String popupHandle = itr.next().toString();
				if (!popupHandle.contains(parWindow)) {
					driver.switchTo().window(popupHandle);
					System.out.println("Popu Up Title: " + driver.switchTo().window(popupHandle).getTitle());
					driver.close();
				}

			}
		}
	}
}
