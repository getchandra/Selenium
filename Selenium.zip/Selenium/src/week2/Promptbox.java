package week2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;

public class Promptbox {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.switchTo().frame("iframeResult");
		driver.findElementByXPath("/html/body/button").click();
		Alert a=driver.switchTo().alert();
		//driver.switchTo().alert().sendKeys("Week 2 Hands on");
		a.sendKeys("Week 2 Hands on");
		a.accept();
		//a.dismiss();
		String B= driver.findElementById("demo").getText();
		System.out.println(B);
		if(B.contains("Week 2 Hands on"))
		{
			System.out.println("pass");
		}else
		{
			System.out.println("fail");	
		}
	}

}
