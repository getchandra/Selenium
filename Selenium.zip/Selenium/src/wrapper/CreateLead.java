package wrapper;

import java.net.MalformedURLException;

public class CreateLead {

	public static void main(String[] args) throws MalformedURLException {
		WrapperMethods wm = new WrapperMethods();
		wm.openApp("firefox", "http://demo1.opentaps.org/");
		wm.enterTextById("username", "DemoSalesManager");
		wm.enterTextById("password", "crmsfa");
		wm.clickByClassName("decorativeSubmit");
		wm.clickByxpath("//*[@id='button']/a/img");
		wm.clickByLinkText("Create Lead");
		wm.enterTextById("createLeadForm_companyName", "Steria");
		wm.enterTextById("createLeadForm_firstName", "Chandra");
		wm.enterTextById("createLeadForm_lastName", "Sekar");
		wm.clickByName("submitButton");
		wm.closeApp();

	}

}
