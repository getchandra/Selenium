package week51;

public class ClassM {
	@SuppressWarnings("unused")
	public static void main(String args[]){
		//ClassC(); will be invisible without no arguments is created
		ClassC obj = new ClassC("Testleaf");
	}

}
