package week51;

public class CallInterface implements WrapperMethodExample,OpenTapsWrapper {
	
	public static void main(String[] args) {
	}

	@Override
	public void invokeApp(String browser, String url) {
			
	}

	@Override
	public void login(String userName, String passWord) {
			
	}


}

