package week51;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

@SuppressWarnings("unused")
public class CallBrowser {

	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.findElement(By.name("Dummy")).click();
		
	}
}

