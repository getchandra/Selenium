package week51;

public class CallAbstract extends AbstractExample {

	@Override
	public void invokeApp(String browser, String url) {
			
	}

	@Override
	public void enterById() {
			
	}

}

