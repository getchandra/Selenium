package week51;

public interface OpenTapsWrapper {
	
	public void login(String userName,String passWord);

}