package week51;

public abstract class AbstractExample implements WrapperMethodExample {
	
	//Abstract class can have abstract method 
	//and Implementation
	
	public abstract void enterById();
	
	public void enterByName(){
		// logic for enter by name
	}

}
