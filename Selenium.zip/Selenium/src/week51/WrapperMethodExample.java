package week51;

public interface WrapperMethodExample {

	//
	//Interface can have only method declaration
	//Interface will not contain implementation
	//Interface do not have a constructor
	//Interface can contain variables
	
	public int stepNumber=1;
	public abstract void invokeApp(String browser, String url);
//	public WrapperMethodExample() {
////	}
//	public void closeBrowser();
}
