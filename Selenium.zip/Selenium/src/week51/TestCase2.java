package week51;

import java.io.IOException;

import org.testng.annotations.Test;

public class TestCase2 extends OpenTapsMethods {
	@Test
	public void testCase2() throws IOException{
		login();
		invokeApp("firefox", "url");
	}
}
