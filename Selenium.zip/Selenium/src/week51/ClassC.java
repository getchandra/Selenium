package week51;

public class ClassC {

	public ClassC() {
		System.out.println("I am inside constructor created by me");
	}
	
	public ClassC(String name) {
		System.out.println("I am inside constructor created "+name);
	}
}
