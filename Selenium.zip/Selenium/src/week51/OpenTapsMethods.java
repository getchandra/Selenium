package week51;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OpenTapsMethods extends WrapperMethods {
	public void login() {

	}

	public void login(String userName, String passWord) {

	}
	
	public void invokeApp(String browserName, String url) throws IOException {
		if (browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("chrome")) {
			//
			driver = new ChromeDriver();

		}

		// Maximize the browser
		driver.manage().window().maximize();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		// Load the URL
		driver.get(url);

		takeSnap();
	}
}

