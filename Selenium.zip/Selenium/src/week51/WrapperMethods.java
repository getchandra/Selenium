package week51;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

@SuppressWarnings("unused")
public class WrapperMethods {

	RemoteWebDriver driver;
	int i = 1;

	public void invokeApp(String browserName, String url) throws IOException {
		if (browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}

		// Maximize the browser
		driver.manage().window().maximize();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// Load the URL
		driver.get(url);

		takeSnap();
	}

	public void enterValueById(String id, String value) throws Exception {
		try {
			driver.findElement(By.id(id)).clear();
			driver.findElement(By.id(id)).sendKeys(value);

		} finally {
			takeSnap();
		}

	}

	public void clickByClassName(String className) throws IOException {
		driver.findElement(By.className(className)).click();
		takeSnap();
	}

	public void verifyTitle(String expectedTitle) throws IOException {
		if (driver.getTitle().equals(expectedTitle)) {
			System.out.println("Titles are matched");
		} else {
			System.out.println("Titles are not matched");
		}
		takeSnap();
	}

	public void closeApp() {
		driver.close();

	}

	public void takeSnap() throws IOException {
		File snapFile = driver.getScreenshotAs(OutputType.FILE);

		FileUtils.copyFile(snapFile, new File("C:\\SelOct\\Selenium\\snap" + i + ".JPEG"));
		i++;

	}

}
