package week51;

public class InheritanceEx {

}
