package week3;

import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CreateLead {
	@Test
	public void Sanity() {
		WebDriver driver = new FirefoxDriver();
		driver.get("http://demo1.opentaps.org/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.xpath("//*[@id='button']/a/img")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Steria");
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Chandrasekhara");
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("Varma");
		driver.findElement(By.name("submitButton")).click();
		driver.close();
	}
}
