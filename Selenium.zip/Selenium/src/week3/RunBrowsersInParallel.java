package week3;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

@SuppressWarnings("unused")
public class RunBrowsersInParallel {
	WebDriver driver1;
	WebDriver driver2;

	@Test

	public void Chrome() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		driver1 = new ChromeDriver();
		driver1.manage().window().maximize();
		driver1.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver1.get("http://www.google.co.in/");
		driver1.close();
	}

	@Test

	public void Firefox() throws InterruptedException {
		driver2 = new FirefoxDriver();
		driver2.manage().window().maximize();
		driver2.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver2.get("https://www.google.co.in");
		driver2.close();

	}

}
