package week3;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Drop {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://JqueryUI.com/sortable");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));
		WebElement element1 = driver.findElement(By.xpath("//*[@id='sortable']/li[1]"));
		WebElement element5 = driver.findElement(By.xpath("//*[@id='sortable']/li[5]"));
		System.out.println(element5.getLocation());
		Actions builder = new Actions(driver);
		builder.clickAndHold(element1).moveToElement(element5).dragAndDropBy(element5, 11, 14).build().perform();
	}

}
