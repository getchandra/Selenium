package week3;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class RightclickAndNewtab {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://the-internet.herokuapp.com/jqueryui/menu");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Set<String> windows = driver.getWindowHandles();
		for (String win : windows)
			System.out.println(win);
		System.out.println("End of first window");
		System.out.println(windows.size());
		Actions actions = new Actions(driver);
		// Thread.sleep(20000);
		actions.contextClick(driver.findElement(By.linkText("Enabled"))).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER)
				.build().perform();
		// Thread.sleep(2000);
		Set<String> windows1 = driver.getWindowHandles();
		for (String win : windows1)
			System.out.println(win);
		System.out.println("End of second window");
		System.out.println(windows1.size());
		driver.close();
	}

}
