package week3;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class AmazonChrome {
	WebDriver driver;

	@BeforeClass
	public void chrome() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://www.amazon.in/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@Test
	public void SearchForBags() {
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("bags");
		driver.findElement(By.className("nav-input")).click();
	}

	@Test(dependsOnMethods = "SearchForBags")
	public void Select4thProduct() {
		driver.findElement(By.xpath("//*[@id='result_3']/div/div/div/div[2]/div[1]/a/h2")).click();
	}

	@Test(dependsOnMethods = "Select4thProduct")
	public void AddtoBasket() {
		driver.findElement(By.id("add-to-cart-button")).click();
	}

	@AfterClass
	public void closeDriver() {
		driver.close();
	}

}
