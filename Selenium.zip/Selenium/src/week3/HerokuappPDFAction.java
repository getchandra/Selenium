package week3;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

@SuppressWarnings("unused")
public class HerokuappPDFAction {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		// System.setProperty("webdriver.chrome.driver",
		// "C:\\Users\\varma\\Desktop\\selenium-64 bit\\drivers\\chromedriver.exe");
		// ChromeDriver driver = new ChromeDriver();
		driver = new FirefoxDriver();
		driver.get("http://the-internet.herokuapp.com/jqueryui/menu");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Actions builder = new Actions(driver);
		builder.moveToElement(driver.findElement(By.linkText("Enabled"))).build().perform();
		builder.moveToElement(driver.findElement(By.linkText("Downloads"))).build().perform();
		builder.moveToElement(driver.findElement(By.linkText("PDF"))).click().build().perform();
		driver.close();

	}

}
