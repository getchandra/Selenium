package week3;

import org.testng.annotations.Test;
import java.util.NoSuchElementException;

public class DummyMethods {
  @Test(invocationCount = 3)
  public void signUp() {
	  System.out.println("Signup completed successfully");  	
	  }
  @Test
  public void logIn() {	
	  System.out.println("LoggedIn successfully"); 
	  throw new NoSuchElementException();
	  }
  @Test(dependsOnMethods = "logIn")
  public void createLead() throws Exception {		
	  System.out.println("Lead created successfully");  	
	  }
  @Test(dependsOnMethods = "logIn")
  public void createAccount() throws Exception {		
	  System.out.println("Account created successfully");  	
	  }
  @Test(enabled = false)
  public void deleteLead() {		
	  System.out.println("Lead deleted successfully");  	
	  }
  @Test(dependsOnMethods = "logIn")
  public void logOut() {		
	  System.out.println("LoggedOut successfully");  	
	  }
 
  }

